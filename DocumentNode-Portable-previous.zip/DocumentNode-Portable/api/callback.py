import json
import os
import re
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import httpx


JOBS_DIR = Path("/data/jobs")


def deliver_result(job_id: str):
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise ValueError("Invalid job_id")

    url = os.getenv("CALLBACK_URL", "").strip()
    token = os.getenv("CALLBACK_TOKEN", "").strip()

    if not url.startswith(("http://", "https://")):
        raise ValueError("CALLBACK_URL not configured")

    job_dir = JOBS_DIR / job_id
    result_path = job_dir / "result.json"

    if not result_path.is_file():
        raise FileNotFoundError("Result JSON not found")

    result = json.loads(
        result_path.read_text(encoding="utf-8")
    )

    headers = {
        "X-Job-ID": job_id,
        "Idempotency-Key": job_id
    }

    if token:
        headers["Authorization"] = f"Bearer {token}"

    with httpx.Client(
        timeout=30,
        follow_redirects=False,
        trust_env=False,
    ) as client:
        response = client.post(
            url,
            json=result,
            headers=headers
        )
        response.raise_for_status()

    receipt = {
        "job_id": job_id,
        "delivered": True,
        "http_status": response.status_code
    }

    tmp = job_dir / "callback.tmp"
    tmp.write_text(
        json.dumps(receipt),
        encoding="utf-8"
    )
    tmp.replace(job_dir / "callback.json")

    return receipt


def deliver_feedback(job_id: str):
    """Deliver a persisted feedback body independently of the result callback."""
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise ValueError("Invalid job_id")
    token = os.getenv("CALLBACK_TOKEN", "").strip()
    explicit_url = os.getenv("FEEDBACK_URL", "").strip()
    callback_url = urlsplit(explicit_url or os.getenv("CALLBACK_URL", "").strip())
    if callback_url.scheme not in {"http", "https"} or not callback_url.netloc or not token:
        raise ValueError("CALLBACK_URL and CALLBACK_TOKEN are required")
    suffix = "/callback/"
    if not explicit_url and not callback_url.path.endswith(suffix):
        raise ValueError("Cannot derive feedback endpoint from CALLBACK_URL")
    url = explicit_url or urlunsplit((callback_url.scheme, callback_url.netloc,
                       callback_url.path[:-len(suffix)] + "/feedback/", "", ""))
    job_dir = JOBS_DIR / job_id
    body = (job_dir / "feedback.json").read_bytes()
    if len(body) > 256 * 1024:
        raise ValueError("Feedback exceeds 256 KiB")
    with httpx.Client(timeout=30, follow_redirects=False, trust_env=False) as client:
        response = client.post(url, content=body, headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        })
    receipt = {"job_id": job_id, "http_status": response.status_code,
               "delivered": response.status_code == 200}
    # Retry transient failures (including the external_job_id registration race).
    if response.status_code in {404, 408, 429} or response.status_code >= 500:
        response.raise_for_status()
    if response.status_code != 200:
        receipt["requires_attention"] = True
    tmp = job_dir / "feedback-receipt.tmp"
    tmp.write_text(json.dumps(receipt), encoding="utf-8")
    tmp.replace(job_dir / "feedback-receipt.json")
    return receipt
