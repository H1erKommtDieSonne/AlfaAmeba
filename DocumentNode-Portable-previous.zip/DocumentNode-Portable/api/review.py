"""Document review policy and validation of model output."""

# Compatibility import; the v2 pipeline uses the prompt in finance_prompt.py.
from finance_prompt import FINANCIAL_SYSTEM_PROMPT as SYSTEM_PROMPT


CODES = {
    "missing_document", "missing_field", "unreadable_document",
    "incomplete_document", "document_mismatch", "inconsistent_data",
    "uncertain_recognition", "manual_review_required",
}


def validate_review(value, files):
    if not isinstance(value, dict):
        raise ValueError("Ожидался объект проверки")
    if value.get("status") not in {"complete", "needs_documents", "needs_review"}:
        raise ValueError("Некорректный статус проверки")
    if not isinstance(value.get("summary"), str) or not value["summary"].strip():
        raise ValueError("Отсутствует итог проверки")
    issues = value.get("issues")
    if not isinstance(issues, list) or len(issues) > 45:
        raise ValueError("Некорректный список замечаний")
    names = {item["filename"] for item in files}
    cleaned = []
    for issue in issues:
        if not isinstance(issue, dict) or issue.get("code") not in CODES:
            raise ValueError("Некорректный код замечания")
        item = {"code": issue["code"]}
        for key in ("message", "suggestion"):
            text = issue.get(key)
            if not isinstance(text, str) or not text.strip() or len(text) > 1000:
                raise ValueError(f"Некорректное поле {key}")
            item[key] = text
        if issue.get("filename") is not None:
            name = issue["filename"]
            if not isinstance(name, str) or name not in names or len(name) > 255:
                raise ValueError("Неизвестное имя документа")
            item["filename"] = name
        cleaned.append(item)
    value["issues"] = cleaned
    for key in ("missing_documents", "recommendations"):
        if not isinstance(value.get(key), list) or not all(
            isinstance(item, str) for item in value[key]
        ):
            raise ValueError(f"Некорректное поле {key}")
    value["documents_checked"] = len(files)
    for item in files:
        if item["truncated"] or item["uncertain_fragments"]:
            cleaned.append({
                "code": "uncertain_recognition",
                "filename": item["filename"],
                "message": "Документ проверен не полностью: текст сокращён или распознан с сомнениями.",
                "suggestion": "Проверьте документ вручную; при необходимости повторите распознавание или замените файл.",
            })
            value["status"] = "needs_review"
    if value["status"] == "complete" and (cleaned or value["missing_documents"]):
        raise ValueError("Полная проверка несовместима с замечаниями")
    if value["status"] != "complete" and not cleaned:
        raise ValueError("Для неполной проверки нужны конкретные замечания")
    return value
