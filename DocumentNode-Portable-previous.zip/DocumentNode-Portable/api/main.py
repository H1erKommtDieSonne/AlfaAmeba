import os
import secrets
import httpx

from fastapi import FastAPI, Header, HTTPException

app = FastAPI(
    title="Local Document AI",
    version="2.0.0"
)

OLLAMA_URL = os.getenv(
    "OLLAMA_URL",
    "http://ollama:11434"
)

API_KEY = os.getenv("API_KEY", "")


def check_api_key(key):
    if not API_KEY:
        raise HTTPException(
            status_code=503,
            detail="API key not configured"
        )

    if not key or not secrets.compare_digest(key, API_KEY):
        raise HTTPException(
            status_code=401,
            detail="Invalid API key"
        )


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/models")
async def models(x_api_key: str | None = Header(default=None)):
    check_api_key(x_api_key)

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{OLLAMA_URL}/api/tags"
            )
            response.raise_for_status()
            data = response.json()

        return {
            "models": [
                model["name"]
                for model in data.get("models", [])
            ]
        }

    except httpx.HTTPError:
        raise HTTPException(
            status_code=502,
            detail="Cannot connect to Ollama"
        )

import json
from pathlib import Path
from fastapi import File, Form, UploadFile
from fastapi.concurrency import run_in_threadpool






def parse_context(raw):
    from finance_schema import ApplicationContext
    from pydantic import ValidationError
    import math
    if len(raw.encode("utf-8")) > 64 * 1024:
        raise HTTPException(400, "Контекст заявки больше 64 KiB")
    try:
        def reject_constant(value):
            raise ValueError("Non-finite JSON number")
        def finite_float(value):
            number = float(value)
            if not math.isfinite(number):
                raise ValueError("Non-finite JSON number")
            return number
        context = json.loads(raw, parse_constant=reject_constant, parse_float=finite_float)
        if not isinstance(context, dict):
            raise ValueError("Expected object")
        context = ApplicationContext.model_validate(context).model_dump(mode="json")
        if len(json.dumps(context, ensure_ascii=False).encode("utf-8")) > 64 * 1024:
            raise ValueError("Normalized context exceeds 64 KiB")
        return context
    except (ValueError, RecursionError, ValidationError):
        raise HTTPException(400, "Некорректный application_context: проверьте JSON, типы, даты, единицы и размер по /docs")


@app.post("/analyze", summary="Синхронная проверка и финансовая подготовка (schema v2)")
async def analyze(
    files: list[UploadFile] = File(...),
    system_prompt: str = Form("Проверь документы и подготовь финансовые данные по стандартному контракту."),
    application_context: str = Form("{}", description="JSON-строка ApplicationContext: ИНН, тип кредита, версия, периоды, сведения провайдера и подтверждения полноты. Схема: GET /financial/schema"),
    x_api_key: str | None = Header(default=None),
):
    check_api_key(x_api_key)
    if not 1 <= len(files) <= 5 or not 0 < len(system_prompt.strip()) <= 20000:
        raise HTTPException(400, "Нужно 1–5 файлов и system_prompt до 20000 символов")
    context = parse_context(application_context)
    uploaded, names = [], set()
    for file in files:
        filename = Path(file.filename or "").name
        if len(filename) > 255 or filename in names:
            raise HTTPException(400, "Имена файлов должны быть уникальными и не длиннее 255 символов")
        names.add(filename)
        if Path(filename).suffix.lower() not in ALLOWED_FORMATS:
            raise HTTPException(415, "Неподдерживаемый формат файла")
        data = await file.read(10 * 1024 * 1024 + 1)
        if not data:
            raise HTTPException(422, "Пустой файл")
        if len(data) > 10 * 1024 * 1024:
            raise HTTPException(413, "Файл больше 10 MiB")
        uploaded.append((filename, data))
    from analysis_pipeline import analyze_files
    try:
        return await run_in_threadpool(analyze_files, uploaded, system_prompt, context, OLLAMA_URL)
    except Exception:
        return {"status": "completed", "verification_status": "needs_review",
                "files": [{"filename": name, "status": "not_checked"} for name, _ in uploaded],
                "result": {"schema_version": 2, "status": "processing_error", "issues": [],
                           "summary": "Техническая ошибка обработки. Проверка не завершена.",
                           "financial_analysis": None, "error": {"code": "document_processing_failed", "retryable": True}}}


from finance_schema import PrepareRequest, AnalystResult, ApplicationContext, ExtractionResponse
from finance import prepare_financial_analysis


@app.post("/financial/prepare", response_model=AnalystResult,
          summary="Подготовить данные для сотрудника и моделей без вызова LLM")
async def financial_prepare(body: PrepareRequest, x_api_key: str | None = Header(default=None)):
    check_api_key(x_api_key)
    try:
        return prepare_financial_analysis(body.application_context, body.financial_data)
    except ValueError:
        raise HTTPException(422, "Невозможно согласовать финансовые данные: проверьте типы, размер набора, даты и единицы по /financial/schema")


@app.get("/financial/schema", summary="JSON Schema входов и финансового результата v2")
async def financial_schema(x_api_key: str | None = Header(default=None)):
    check_api_key(x_api_key)
    return {"schema_version": 2, "prepare_request": PrepareRequest.model_json_schema(),
            "application_context": ApplicationContext.model_json_schema(),
            "extraction_response": ExtractionResponse.model_json_schema(),
            "analyst_result": AnalystResult.model_json_schema()}


# Асинхронная загрузка пакетов документов
import uuid
import shutil

from redis import Redis
from rq import Queue


JOBS_DIR = Path("/data/jobs")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")

ALLOWED_FORMATS = {
    ".pdf", ".jpg", ".jpeg", ".png",
    ".tif", ".tiff", ".docx", ".xlsx",
    ".pptx", ".txt", ".csv", ".json", ".md"
}


@app.post("/jobs", status_code=202, summary="Поставить полный комплект документов в очередь; результат schema v2")
async def create_job(
    files: list[UploadFile] = File(...),
    system_prompt: str = Form("Проверь документы и подготовь финансовые данные по стандартному контракту."),
    application_context: str = Form("{}", description="JSON-строка ApplicationContext: ИНН, тип кредита, версия, периоды, сведения провайдера и подтверждения полноты. Схема: GET /financial/schema"),
    x_api_key: str | None = Header(default=None)
):
    check_api_key(x_api_key)

    if not 1 <= len(files) <= 5:
        raise HTTPException(
            400, "Разрешено от 1 до 5 файлов"
        )

    if not 0 < len(system_prompt.strip()) <= 20000:
        raise HTTPException(
            400, "Некорректный системный промпт"
        )

    context = parse_context(application_context)

    job_id = uuid.uuid4().hex
    job_dir = JOBS_DIR / job_id

    manifest = {
        "job_id": job_id,
        "system_prompt": system_prompt,
        "application_context": context,
        "files": []
    }

    try:
        job_dir.mkdir(
            parents=True,
            mode=0o700,
            exist_ok=False
        )

        names = set()
        for index, file in enumerate(files, 1):
            filename = Path(file.filename or "").name
            ext = Path(filename).suffix.lower()
            if len(filename) > 255 or filename in names:
                raise HTTPException(400, "Имена файлов должны быть уникальными и не длиннее 255 символов")
            names.add(filename)

            if ext not in ALLOWED_FORMATS:
                raise HTTPException(
                    415,
                    f"Неподдерживаемый формат: {filename}"
                )

            data = await file.read(10 * 1024 * 1024 + 1)

            if len(data) > 10 * 1024 * 1024:
                raise HTTPException(
                    413,
                    f"Файл больше 10 МБ: {filename}"
                )

            if not data:
                raise HTTPException(
                    422,
                    f"Пустой файл: {filename}"
                )

            stored_name = f"document_{index:02d}{ext}"

            (job_dir / stored_name).write_bytes(data)

            manifest["files"].append({
                "filename": filename,
                "stored_name": stored_name
            })

        (job_dir / "manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False),
            encoding="utf-8"
        )

        redis = Redis.from_url(REDIS_URL)

        queue = Queue(
            "docs",
            connection=redis,
            serializer="json"
        )

        queue.enqueue(
            "tasks.process_documents",
            job_id,
            job_id=job_id,
            job_timeout=10800,
            result_ttl=86400,
            failure_ttl=86400
        )

    except HTTPException:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise

    except Exception:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(
            503, "Не удалось создать задание"
        )

    return {
        "job_id": job_id,
        "status": "queued",
        "files_count": len(files),
        "message": "Документы поставлены в очередь"
    }

import re

from rq.job import Job
from rq.exceptions import NoSuchJobError
from redis.exceptions import RedisError


@app.get("/jobs/{job_id}")
async def get_job(
    job_id: str,
    x_api_key: str | None = Header(default=None)
):
    check_api_key(x_api_key)

    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise HTTPException(400, "Некорректный job_id")

    # A saved report survives RQ result expiration or a delivery-queue failure.
    result_path = JOBS_DIR / job_id / "result.json"
    if result_path.is_file():
        try:
            return json.loads(result_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raise HTTPException(500, "Ошибка чтения результата")

    try:
        redis = Redis.from_url(REDIS_URL)

        job = Job.fetch(
            job_id,
            connection=redis,
            serializer="json"
        )

        state = job.get_status(refresh=True)
        status = state.value if hasattr(state, "value") else str(state)

    except NoSuchJobError:
        raise HTTPException(404, "Задание не найдено")

    except RedisError:
        raise HTTPException(503, "Redis недоступен")

    if status == "finished":
        result_path = JOBS_DIR / job_id / "result.json"

        if not result_path.is_file():
            raise HTTPException(500, "Результат отсутствует")

        try:
            return json.loads(
                result_path.read_text(encoding="utf-8")
            )
        except (OSError, ValueError):
            raise HTTPException(500, "Ошибка чтения результата")

    if status == "failed":
        return {
            "job_id": job_id,
            "status": "failed",
            "message": "Ошибка обработки документов"
        }

    return {
        "job_id": job_id,
        "status": status
    }


@app.get("/jobs/{job_id}/delivery", summary="Подтверждения доставки callback и feedback")
async def get_delivery(job_id: str, x_api_key: str | None = Header(default=None)):
    check_api_key(x_api_key)
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise HTTPException(400, "Некорректный job_id")
    folder = JOBS_DIR / job_id
    if not (folder / "manifest.json").is_file():
        raise HTTPException(404, "Задание не найдено")
    def receipt(name):
        path = folder / name
        if not path.is_file():
            return {"delivered": False, "state": "no_receipt"}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raise HTTPException(500, "Ошибка чтения подтверждения доставки")
    return {"job_id": job_id, "result_saved": (folder / "result.json").is_file(),
            "callback": receipt("callback.json"),
            "feedback": receipt("feedback-receipt.json") if (folder / "feedback.json").is_file()
                        else {"state": "not_created"}}
