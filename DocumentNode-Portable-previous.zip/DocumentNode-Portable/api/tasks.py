import json
import logging
import os
import re
import uuid
from pathlib import Path

import httpx



OLLAMA_URL = os.getenv(
    "OLLAMA_URL", "http://ollama:11434"
)

MODEL = os.getenv("DOCUMENT_MODEL", "qwen3.5:35b-a3b")
JOBS_DIR = Path("/data/jobs")

def _analyze_documents(job_id: str):
    from analysis_pipeline import analyze_files

    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise ValueError("Некорректный job_id")
    job_dir = JOBS_DIR / job_id
    manifest = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))

    def files():
        for item in manifest["files"]:
            path = (job_dir / item["stored_name"]).resolve()
            if path.parent != job_dir.resolve():
                raise ValueError("Недопустимый путь файла")
            yield item["filename"], path.read_bytes()

    result = analyze_files(files(), manifest["system_prompt"],
                           manifest.get("application_context", {}), OLLAMA_URL)
    return {"job_id": job_id, **result}


def _save_and_dispatch(job_id, result):
    job_dir = JOBS_DIR / job_id
    analysis = result["result"]
    # Атомарное сохранение результата
    temp_path = job_dir / "result.tmp"
    final_path = job_dir / "result.json"

    temp_path.write_text(
        json.dumps(
            result,
            ensure_ascii=False,
            indent=2
        ),
        encoding="utf-8"
    )

    temp_path.replace(final_path)

    # Persist once so every delivery retry uses the same idempotency key/body.
    feedback_path = job_dir / "feedback.json"
    if analysis.get("issues") and not feedback_path.exists():
        feedback = {
            "feedback_id": str(uuid.uuid4()),
            "job_id": job_id,
            "issues": [],
        }
        for issue in analysis["issues"][:50]:
            feedback["issues"].append(issue)
            if len(json.dumps(feedback, ensure_ascii=False, allow_nan=False).encode("utf-8")) > 256 * 1024:
                feedback["issues"].pop()
                break
        temp_feedback = job_dir / "feedback.tmp"
        temp_feedback.write_text(
            json.dumps(feedback, ensure_ascii=False, allow_nan=False),
            encoding="utf-8",
        )
        temp_feedback.replace(feedback_path)

    callback_status = "not_configured"

    if os.getenv("CALLBACK_URL", "").strip():

        from redis import Redis
        from rq import Queue, Retry

        redis = Redis.from_url(
            os.getenv("REDIS_URL", "redis://redis:6379/0")
        )

        callback_queue = Queue(
            "callbacks",
            connection=redis,
            serializer="json"
        )

        callback_queue.enqueue(
            "callback.deliver_result",
            job_id,
            job_timeout=90,
            retry=Retry(
                max=5,
                interval=[15, 60, 180, 600, 1800]
            ),
            result_ttl=86400,
            failure_ttl=604800
        )

        if analysis.get("issues"):
            callback_queue.enqueue(
                "callback.deliver_feedback",
                job_id,
                job_timeout=90,
                retry=Retry(max=5, interval=[15, 60, 180, 600, 1800]),
                result_ttl=86400,
                failure_ttl=604800,
            )

        callback_status = "queued"

    return {
        "job_id": job_id,
        "status": "completed",
        "callback_status": callback_status
    }



def process_documents(job_id: str):
    """Finish with a deliverable report even if document processing fails.

    Infrastructure failures while saving/enqueueing remain RQ failures. Retrying
    the task reuses the persisted report instead of generating a different one.
    """
    if not re.fullmatch(r"[0-9a-f]{32}", job_id):
        raise ValueError("Некорректный job_id")
    job_dir = JOBS_DIR / job_id
    manifest = json.loads((job_dir / "manifest.json").read_text(encoding="utf-8"))
    result_path = job_dir / "result.json"
    if result_path.is_file():
        result = json.loads(result_path.read_text(encoding="utf-8"))
    else:
        try:
            result = _analyze_documents(job_id)
        except Exception:
            logging.exception("Document processing failed for job %s", job_id)
            result = {
                "job_id": job_id, "status": "completed",
                "verification_status": "needs_review", "model": MODEL,
                "files": [{"filename": item["filename"], "status": "not_checked"}
                          for item in manifest["files"]],
                "result": {
                    "status": "processing_error",
                    "summary": "Техническая ошибка обработки. Проверка документов не завершена.",
                    "error": {"code": "document_processing_failed", "retryable": True},
                    "issues": [], "missing_documents": [], "recommendations": [],
                    "documents_checked": 0, "financial_analysis": None,
                },
            }
        result["result"]["application_context"] = manifest.get("application_context", {})
        result["result"]["schema_version"] = result["result"].get("schema_version", 2)
    return _save_and_dispatch(job_id, result)
