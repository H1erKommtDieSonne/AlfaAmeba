from io import BytesIO
from pathlib import Path


from docx import Document
from openpyxl import load_workbook
from pptx import Presentation


def extract_text(filename: str, data: bytes) -> str:
    ext = Path(filename).suffix.lower()

    # Word
    if ext == ".docx":
        doc = Document(BytesIO(data))
        parts = [p.text for p in doc.paragraphs]

        for table in doc.tables:
            for row in table.rows:
                parts.append(
                    " | ".join(cell.text for cell in row.cells)
                )

        return "\n".join(parts)

    # Excel
    if ext == ".xlsx":
        wb = load_workbook(
            BytesIO(data),
            read_only=True,
            data_only=True
        )
        parts = []

        for sheet in wb:
            parts.append(f"Лист: {sheet.title}")

            for row in sheet.iter_rows(values_only=True):
                parts.append(
                    " | ".join(
                        str(v) if v is not None else ""
                        for v in row
                    )
                )

        wb.close()
        return "\n".join(parts)

    # PowerPoint
    if ext == ".pptx":
        ppt = Presentation(BytesIO(data))
        parts = []

        for i, slide in enumerate(ppt.slides, 1):
            parts.append(f"Слайд {i}")

            for shape in slide.shapes:
                if shape.has_text_frame:
                    parts.append(shape.text)

        return "\n".join(parts)

    # Текстовые файлы
    if ext in (".txt", ".csv", ".json", ".md"):
        return data.decode("utf-8-sig", errors="replace")

    raise ValueError(f"Неподдерживаемый формат: {ext}")
