class ModelProcessingError(RuntimeError):
    """Inference/structured-output failure, not evidence of a defective document."""
