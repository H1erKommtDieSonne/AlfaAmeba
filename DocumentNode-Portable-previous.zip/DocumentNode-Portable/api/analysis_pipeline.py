"""File extraction, evidence validation, and the common v2 analyst result."""
import asyncio
import hashlib
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

from bank_csv import parse_bank_csv
from extract import extract_text
from finance import prepare_financial_analysis
from finance_prompt import FINANCIAL_SYSTEM_PROMPT
from finance_schema import ApplicationContext, ExtractionResponse, FinancialData
from final_analysis import build_final_analysis
from processing_errors import ModelProcessingError

MODEL = os.getenv("DOCUMENT_MODEL", "qwen3.5:35b-a3b")
CHUNK_SIZE = 12000
MAX_CHUNKS = 12


def _text(filename, content, ollama_url):
    suffix = Path(filename).suffix.lower()
    if suffix == ".pdf":
        import pymupdf
        with pymupdf.open(stream=content, filetype="pdf") as document:
            pages = [page.get_text() for page in document]
        if pages and all(len(page.strip()) >= 40 for page in pages):
            return "\n\n".join(f"Страница {index}:\n{page}" for index, page in enumerate(pages, 1)), "pdf_text", []
    if suffix in {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}:
        from vision import vision_transcribe
        output = asyncio.run(vision_transcribe(filename, content, ollama_url))
        return output["text"], "qwen_vision", output["uncertain_fragments"]
    return extract_text(filename, content), "native_text", []


def _call_model(filename, fragment, context, system_prompt, ollama_url):
    # Do not repeat external financial data to the model as if extracted from a file.
    metadata = context.model_dump(mode="json", exclude={"financial_data", "provider_reports", "statement_periods"})
    schema = ExtractionResponse.model_json_schema()
    source_schema = schema["$defs"]["Source"]
    source_schema["properties"]["filename"] = {"type": "string", "const": filename}
    source_schema["properties"]["provider"] = {"type": "null"}
    source_schema["properties"]["is_mock"] = {"type": "boolean", "const": False}
    source_schema["properties"]["quote"]["minLength"] = 1
    source_schema["required"] = list(dict.fromkeys(source_schema.get("required", []) + ["filename", "quote"]))
    for name in ("DocumentType", "ExtractionIssue"):
        schema["$defs"][name]["properties"]["filename"] = {"type": "string", "const": filename}
    payload = {
        "model": MODEL, "think": False, "stream": False,
        "format": schema,
        "messages": [
            {"role": "system", "content": FINANCIAL_SYSTEM_PROMPT + "\nТребования сервера:\n" + system_prompt
             + "\nКонтекст заявки:\n" + json.dumps(metadata, ensure_ascii=False)},
            {"role": "user", "content": json.dumps({"filename": filename, "fragment": fragment}, ensure_ascii=False)},
        ],
        "options": {"temperature": 0, "num_predict": 8192, "num_ctx": 32768},
    }
    with httpx.Client(timeout=1800, trust_env=False) as client:
        response = client.post(f"{ollama_url}/api/chat", json=payload)
        response.raise_for_status()
    output = response.json()
    if output.get("done_reason") != "stop":
        raise ValueError("Модель не завершила структурированный ответ")
    raw = json.loads(output["message"]["content"])
    # File identity is known by the orchestrator, never inferred from document text.
    for field in FinancialData.model_fields:
        for item in raw.get("financial_data", {}).get(field, []):
            if isinstance(item, dict) and isinstance(item.get("source"), dict) and not item["source"].get("filename"):
                item["source"]["filename"] = filename
    return ExtractionResponse.model_validate(raw)


def analyze_files(files, system_prompt, application_context, ollama_url):
    """files is an iterable of (safe original filename, bytes); no queue side effects."""
    started = time.monotonic()
    started_at = datetime.now(timezone.utc).isoformat()
    context = ApplicationContext.model_validate(application_context)
    data, issues, file_info, categories = FinancialData(), [], [], set()
    chunks_used = 0
    blocked = set()
    for filename, content in files:
        info = {"filename": filename, "method": "not_read", "truncated": False,
                "uncertain_fragments": [], "verified": False, "status": "checked",
                "sha256": hashlib.sha256(content).hexdigest(), "categories": []}
        file_info.append(info)
        if Path(filename).suffix.lower() == ".csv":
            try:
                parsed = parse_bank_csv(filename, content, context)
            except (ValueError, UnicodeError) as exc:
                issues.append({"code": "inconsistent_data", "filename": filename,
                               "message": str(exc)[:1000], "suggestion": "Проверьте формат CSV и период/остатки выписки, затем загрузите исправленный файл."})
                info["status"] = "needs_review"
                blocked.add(filename)
                continue
            if parsed is not None:
                data.cash_flow_months.extend(parsed.cash_flow_months)
                categories.add("bank_statement")
                info.update(method="structured_csv", categories=["bank_statement"])
                continue
        try:
            text, method, uncertain = _text(filename, content, ollama_url)
        except (httpx.HTTPError, ModelProcessingError):
            raise  # Infrastructure failures must never masquerade as missing client data.
        except Exception as exc:
            info["status"] = "needs_review"
            blocked.add(filename)
            issues.append({"code": "unreadable_document", "filename": filename,
                           "message": f"Файл не прочитан: {str(exc)[:800]}",
                           "suggestion": "Предоставьте читаемый исходный файл или проверьте документ вручную."})
            continue
        info.update(method=method, uncertain_fragments=uncertain)
        if not text.strip():
            info["status"] = "needs_review"
            blocked.add(filename)
            issues.append({"code": "unreadable_document", "filename": filename, "message": "Текст документа не извлечён",
                           "suggestion": "Загрузите читаемый документ или оригинальную электронную выписку."})
            continue
        for start in range(0, len(text), CHUNK_SIZE):
            if chunks_used >= MAX_CHUNKS:
                info["truncated"] = True
                blocked.add(filename)
                break
            fragment = text[start:start + CHUNK_SIZE]
            extracted = _call_model(filename, fragment, context, system_prompt, ollama_url)
            chunks_used += 1
            for item in extracted.document_types:
                if item.filename == filename:
                    categories.add(item.category)
                    if item.category not in info["categories"]:
                        info["categories"].append(item.category)
            issues.extend(issue.model_dump() for issue in extracted.issues if issue.filename == filename)
            if any(issue.filename == filename and issue.code in {"unreadable_document", "incomplete_document", "uncertain_recognition"} for issue in extracted.issues):
                blocked.add(filename)
                info["status"] = "needs_review"
            normalized = " ".join(fragment.split())
            for field in FinancialData.model_fields:
                for item in getattr(extracted.financial_data, field):
                    source = item.source
                    if source.filename != filename or source.provider or source.is_mock or not source.quote.strip() or " ".join(source.quote.split()) not in normalized:
                        issues.append({"code": "uncertain_recognition", "filename": filename,
                                       "message": "Извлечённое значение исключено: отсутствует проверяемая цитата текущего фрагмента.",
                                       "suggestion": "Сверьте значение и его период с оригиналом документа; при необходимости предоставьте расшифровку."})
                        continue
                    getattr(data, field).append(item)
        if info["truncated"] or uncertain:
            blocked.add(filename)
            info["status"] = "needs_review"
            issues.append({"code": "uncertain_recognition", "filename": filename,
                           "message": "Проверка файла неполная: достигнут лимит фрагментов или есть сомнения OCR. Его финансовые значения не включены в расчёт.",
                           "suggestion": "Проверьте документ вручную либо предоставьте машиночитаемые данные; не считайте это доказательством отсутствия поля в оригинале."})
    for field in FinancialData.model_fields:
        setattr(data, field, [item for item in getattr(data, field) if item.source.filename not in blocked])
    analysis = prepare_financial_analysis(context, data)
    required = {"bank_statement": "Выписка по расчётному счёту"}
    loan_aliases = {"оборотный": "working_capital", "оборотный кредит": "working_capital",
                    "контрактный": "contract", "контрактный кредит": "contract",
                    "инвестиционный": "investment", "инвестиционный кредит": "investment",
                    "рефинансирование": "refinancing"}
    loan = loan_aliases.get((context.loan_type or "").lower(), context.loan_type)
    if loan == "contract":
        required["contract"] = "Контракт"
        if context.contract_appendices_required:
            required["contract_appendix"] = "Предусмотренные контрактом приложения"
    if loan == "investment" and not categories & {"estimate", "supplier_offer"}:
        required["estimate"] = "Смета ИЛИ предложение поставщика"
    if loan == "refinancing":
        required.update(credit_agreement="Договоры рефинансируемых кредитов", debt_schedule="Графики платежей", debt_balance="Сведения об остатках долга")
    if context.has_collateral:
        required["collateral_ownership"] = "Подтверждение права собственности на залог"
    if loan not in {"working_capital", "contract", "investment", "refinancing"}:
        analysis["employee_recommendations"].append({"code": "loan_type_missing", "message": "Укажите loan_type: working_capital, contract, investment или refinancing. Тип кредита не определён автоматически."})
        issues.append({"code": "manual_review_required", "message": "Тип кредитного продукта не передан или неизвестен", "suggestion": "Уточните тип заявки на стороне банка."})
    for category, label in required.items():
        if category not in categories:
            analysis["client_requests"].append({"code": f"document_{category}", "title": label,
                "message": f"Не подтверждено наличие читаемого документа: {label}. Загрузите документ или уточните категорию уже загруженного файла.",
                "fields": [], "required_for": ["product_document_check"], "priority": "required", "action": "upload_or_clarify"})
    for item in analysis["client_requests"]:
        if item["priority"] == "required":
            detail = ". Не получены данные: " + ", ".join(item["fields"]) if item["fields"] else ""
            issue = {"code": "missing_document" if item["code"].startswith("document_") else "missing_field",
                     "message": (item["title"] + detail)[:1000], "suggestion": item["message"][:1000]}
            if len(item["fields"]) == 1:
                issue["field"] = item["fields"][0][:120]
            issues.append(issue)
    for info in file_info:
        if info["status"] == "needs_review" or info["truncated"]:
            analysis["client_requests"].append({"code": "document_requires_review", "title": "Проверить или заменить документ",
                "message": f"Файл {info['filename']} не проверен полностью. Сверьте замечания; при необходимости загрузите читаемую версию.",
                "filename": info["filename"], "priority": "required", "action": "review_or_replace",
                "fields": [], "required_for": ["document_quality"]})
    from ml_client import enrich_with_models
    enrich_with_models(analysis)
    final_analysis = build_final_analysis(
        analysis,
        context,
        ollama_url=ollama_url,
        model=MODEL,
    )
    unique = {json.dumps(issue, sort_keys=True, ensure_ascii=False): issue for issue in issues}
    issues = list(unique.values())
    review_required = analysis["model_outputs"]["status"] == "failed" or bool(blocked) or any(issue["code"] not in {"missing_field", "missing_document"} for issue in issues) or any(w["code"] in {"conflicting_metrics", "subject_mismatch", "conflicting_cash_month", "conflicting_debt_schedule", "debt_confirmation_conflict"} for w in analysis["warnings"])
    status = "needs_review" if review_required else "needs_documents" if any(item["priority"] == "required" for item in analysis["client_requests"]) else "complete"
    return {"status": "completed", "verification_status": "needs_review" if status != "complete" else "not_verified",
            "model": MODEL, "files": file_info,
            "result": {"schema_version": 2, "status": status,
                       "summary": "Данные подготовлены. Проверьте готовность каждого вида анализа и запросы дополнительной информации.",
                       "issues": issues, "missing_documents": [item["title"] for item in analysis["client_requests"] if item["priority"] == "required"],
                       "recommendations": [item["message"] for item in analysis["employee_recommendations"]],
                       "documents_checked": sum(info["status"] == "checked" for info in file_info),
                       "financial_analysis": analysis,
                       "final_analysis": final_analysis,
                       "processing": {"started_at": started_at, "completed_at": datetime.now(timezone.utc).isoformat(),
                                      "duration_ms": round((time.monotonic() - started) * 1000),
                                      "files_received": len(file_info),
                                      "accepted_observations": sum(len(getattr(data, field)) for field in FinancialData.model_fields),
                                      "llm_chunks": chunks_used}}}
