"""Versioned, validated inputs for financial extraction and deterministic analysis."""
from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, StrictFloat, field_validator, model_validator

MetricName = Literal[
    "revenue", "net_profit_current", "operating_profit_current", "total_assets",
    "equity", "current_assets", "short_term_liabilities", "cash", "receivables", "okved_group",
]
Unit = Literal["RUB", "RUB_THOUSANDS"]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)

    @field_validator("*", mode="before")
    @classmethod
    def bounded_numbers(cls, value, info):
        numeric = {"value", "amount", "opening_balance", "closing_balance", "inflows", "outflows",
                   "customer_receipts", "operating_payments", "debt_service", "principal", "interest", "fees",
                   "opening_balance_rub", "closing_balance_rub"}
        if info.field_name in numeric and (isinstance(value, bool) or isinstance(value, (int, float)) and abs(value) > 1e18):
            raise ValueError("Expected a finite monetary value with absolute value <= 1e18")
        return value


class Source(StrictModel):
    filename: str | None = Field(None, max_length=255)
    provider: str | None = Field(None, max_length=120)
    locator: str = Field(..., min_length=1, max_length=200)
    quote: str = Field("", max_length=1500)
    is_mock: bool = False

    @model_validator(mode="after")
    def located(self):
        if not self.filename and not self.provider:
            raise ValueError("Source requires filename or provider")
        return self


class Observation(StrictModel):
    field: MetricName
    value: StrictFloat | str | None
    unit: Literal["RUB", "RUB_THOUSANDS", "CODE"]
    period_start: date | None = None
    period_end: date | None = None
    as_of: date | None = None
    subject_inn: str | None = Field(None, pattern=r"^[0-9]{10}([0-9]{2})?$")
    source: Source

    @model_validator(mode="after")
    def value_type(self):
        if self.field == "okved_group":
            if self.unit != "CODE" or (self.value is not None and not isinstance(self.value, str)):
                raise ValueError("OKVED requires string and CODE unit")
        elif self.unit == "CODE" or isinstance(self.value, (str, bool)):
            raise ValueError("Financial values must be numeric, not strings")
        return self


class CounterpartyReceipt(StrictModel):
    counterparty_id: str = Field(..., min_length=1, max_length=120)
    amount: float = Field(..., ge=0)


class CashMonth(StrictModel):
    account_id: str = Field(..., min_length=1, max_length=120)
    month: str = Field(..., pattern=r"^[0-9]{4}-(0[1-9]|1[0-2])$")
    coverage_start: date
    coverage_end: date
    complete_month: bool = False
    currency: Literal["RUB"]
    unit: Unit
    opening_balance: float | None = None
    closing_balance: float | None = None
    inflows: float | None = Field(None, ge=0)
    outflows: float | None = Field(None, ge=0)
    customer_receipts: float | None = Field(None, ge=0)
    operating_payments: float | None = Field(None, ge=0)
    debt_service: float | None = Field(None, ge=0)
    customer_breakdown: list[CounterpartyReceipt] = Field(default_factory=list, max_length=1000)
    source: Source

    @model_validator(mode="after")
    def dates(self):
        year = int(self.month[:4])
        if not 2000 <= year <= 2100 or self.coverage_start > self.coverage_end:
            raise ValueError("Invalid cash flow coverage dates")
        if self.coverage_start.strftime("%Y-%m") != self.month or self.coverage_end.strftime("%Y-%m") != self.month:
            raise ValueError("Coverage must belong to the given month")
        return self


class DebtPayment(StrictModel):
    loan_id: str = Field(..., min_length=1, max_length=120)
    due_date: date
    principal: float | None = Field(None, ge=0)
    interest: float | None = Field(None, ge=0)
    fees: float | None = Field(None, ge=0)
    total_payment: float | None = Field(None, ge=0)
    unit: Unit
    source: Source


class Supplement(StrictModel):
    field: Literal["ebitda", "total_debt", "cfads", "collateral_value"]
    value: float
    unit: Unit
    period_start: date | None = None
    period_end: date | None = None
    as_of: date | None = None
    source: Source


class DocumentField(StrictModel):
    name: str = Field(..., pattern=r"^[a-z][a-z0-9_]{0,63}$")
    value: StrictFloat | str | None
    unit: Literal["RUB", "RUB_THOUSANDS", "TEXT", "DATE", "CODE", "NUMBER"]
    source: Source

    @model_validator(mode="after")
    def field_type(self):
        if self.value is not None and self.unit in {"RUB", "RUB_THOUSANDS", "NUMBER"} and isinstance(self.value, str):
            raise ValueError("Numeric field requires numeric value")
        if self.value is not None and self.unit in {"TEXT", "DATE", "CODE"} and not isinstance(self.value, str):
            raise ValueError("Text/code/date field requires a string")
        if self.unit == "DATE" and self.value is not None:
            date.fromisoformat(self.value)
        return self


class FinancialData(StrictModel):
    annual_metrics: list[Observation] = Field(default_factory=list, max_length=200)
    cash_flow_months: list[CashMonth] = Field(default_factory=list, max_length=600)
    debt_payments: list[DebtPayment] = Field(default_factory=list, max_length=1000)
    supplemental_metrics: list[Supplement] = Field(default_factory=list, max_length=100)
    document_fields: list[DocumentField] = Field(default_factory=list, max_length=300)


class StatementPeriod(StrictModel):
    filename: str = Field(..., max_length=255)
    account_id: str = Field(..., min_length=1, max_length=120)
    period_start: date
    period_end: date
    opening_balance_rub: float
    closing_balance_rub: float
    complete: bool = False


class ProviderOrganization(BaseModel):
    model_config = ConfigDict(extra="ignore")
    inn: str = Field(..., pattern=r"^[0-9]{10}([0-9]{2})?$")


class ProviderReport(BaseModel):
    """Accept the metadata envelope returned by mock-bo /metrics."""
    model_config = ConfigDict(extra="ignore", allow_inf_nan=False)
    provider: str = Field(..., min_length=1, max_length=120)
    is_mock: bool
    organization: ProviderOrganization
    currency: Literal["RUB"]
    unit: Unit
    period_start: date
    period_end: date
    as_of: date
    metrics: dict[MetricName, StrictFloat | str | None]

    @model_validator(mode="after")
    def metric_types(self):
        for field, value in self.metrics.items():
            if value is not None and (field == "okved_group" and not isinstance(value, str) or field != "okved_group" and isinstance(value, str)):
                raise ValueError("Provider metrics must use numeric financial values and string OKVED")
        return self


class ApplicationContext(BaseModel):
    # Preserve earlier custom context fields, while validating analytical fields.
    model_config = ConfigDict(extra="allow", allow_inf_nan=False)
    application_id: str | int | None = None
    document_version: int | None = Field(None, ge=1)
    borrower_inn: str | None = Field(None, pattern=r"^[0-9]{10}([0-9]{2})?$")
    # Optional product slug relayed by the Django sender; loan_type is derived
    # from the same product on the sender side. Neither field is guessed.
    product_code: str | None = Field(
        None, max_length=64, pattern=r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$"
    )
    loan_type: str | None = None
    loan_amount_rub: StrictFloat | None = Field(None, ge=0, le=1e18)
    term_months: int | None = Field(None, ge=1, le=600)
    purpose: str | None = Field(None, max_length=1000)
    annual_rate_percent: StrictFloat | None = Field(None, ge=0, le=1000)
    has_collateral: bool = False
    contract_appendices_required: bool = False
    reporting_year: int | None = Field(None, ge=2000, le=2100)
    analysis_date: date = Field(default_factory=date.today)
    forecast_month: str | None = Field(None, pattern=r"^20[0-9]{2}-(0[1-9]|1[0-2])$")
    expected_account_ids: list[str] = Field(default_factory=list, max_length=100)
    no_existing_debt_confirmed: bool = False
    debt_schedule_complete: bool = False
    debt_schedule_start: date | None = None
    debt_schedule_end: date | None = None
    proposed_monthly_payment_rub: StrictFloat | None = Field(None, ge=0, le=1e18)
    financial_data: FinancialData = Field(default_factory=FinancialData)
    provider_reports: list[ProviderReport] = Field(default_factory=list, max_length=5)
    statement_periods: list[StatementPeriod] = Field(default_factory=list, max_length=600)


class ExtractionIssue(StrictModel):
    code: Literal["missing_field", "unreadable_document", "incomplete_document",
                  "document_mismatch", "inconsistent_data", "uncertain_recognition", "manual_review_required"]
    message: str = Field(..., min_length=1, max_length=1000)
    suggestion: str = Field(..., min_length=1, max_length=1000)
    filename: str = Field(..., min_length=1, max_length=255)


class DocumentType(StrictModel):
    filename: str
    category: Literal["bank_statement", "balance", "income_statement", "management_report",
                      "tax_return", "income_book", "assets_liabilities", "registry", "contract",
                      "contract_appendix", "estimate", "supplier_offer", "credit_agreement",
                      "debt_schedule", "debt_balance", "collateral_ownership", "collateral_valuation", "other"]


class ExtractionResponse(StrictModel):
    document_types: list[DocumentType] = Field(default_factory=list, max_length=30)
    issues: list[ExtractionIssue] = Field(default_factory=list, max_length=30)
    financial_data: FinancialData = Field(default_factory=FinancialData)


class PrepareRequest(StrictModel):
    application_context: ApplicationContext
    financial_data: FinancialData = Field(default_factory=FinancialData)


class AnnualMetrics(StrictModel):
    revenue: float | None
    net_profit_current: float | None
    operating_profit_current: float | None
    total_assets: float | None
    equity: float | None
    current_assets: float | None
    short_term_liabilities: float | None
    cash: float | None
    receivables: float | None
    okved_group: str | None


class AnnualInput(StrictModel):
    metrics: AnnualMetrics
    unit: Literal["RUB_THOUSANDS"]
    currency: Literal["RUB"]
    period_start: date | None
    period_end: date | None
    as_of: date | None
    ready: bool
    missing_fields: list[MetricName]
    sources: dict[MetricName, list[Source]]


class MonthlyAggregate(StrictModel):
    month: str
    complete: bool
    unit: Literal["RUB"]
    accounts: list[str]
    sources: list[Source]
    opening_balance: float | None
    closing_balance: float | None
    inflows: float | None
    outflows: float | None
    customer_receipts: float | None
    operating_payments: float | None
    debt_service: float | None
    customer_breakdown: dict[str, float] | None


class CashFlowOutput(StrictModel):
    unit: Literal["RUB"]
    currency: Literal["RUB"]
    months: list[MonthlyAggregate]
    complete_months: int
    accounts_confirmed: bool
    average_monthly_inflows_rub: float | None
    average_monthly_outflows_rub: float | None
    average_month_end_balance_rub: float | None
    latest_observed_balance_rub: float | None
    latest_observed_balance_date: date | None


class Statistic(StrictModel):
    value: float | None
    unit: Literal["RUB", "ratio"]
    formula: str
    status: Literal["available", "unavailable"]
    reason: str | None = None
    inputs: dict | None = None
    sources: list[Source] = Field(default_factory=list)


class ForecastScenario(StrictModel):
    name: Literal["base", "cautious", "stress"]
    assumptions: dict[str, float]
    customer_receipts_rub: float
    operating_payments_rub: float
    existing_debt_service_rub: float | None
    proposed_credit_payment_rub: float | None
    starting_observed_balance_rub: float
    opening_balance_rub: float | None
    balance_after_existing_debt_rub: float | None
    balance_after_all_debt_rub: float | None
    cash_gap_rub: float | None
    projection_path: list[dict]


class Backtest(StrictModel):
    folds: int
    mae_rub: float | None
    mape_percent: float | None


class ForecastOutput(StrictModel):
    ready: bool
    period: str | None
    forecast_as_of: date
    data_as_of: date | None
    horizon_months_after_last_observation: int | None
    unit: Literal["RUB"]
    method: Literal["mean_last_3_complete_consecutive_months"]
    scenarios: list[ForecastScenario]
    backtest: Backtest
    cash_gap_probability: None = None
    confidence_interval: None = None
    limitations: list[str]


class ClientRequest(StrictModel):
    code: str
    title: str
    message: str
    fields: list[str]
    required_for: list[str]
    priority: Literal["required", "optional"]
    action: Literal["upload_or_clarify", "review_or_replace"]
    filename: str | None = None


class Recommendation(StrictModel):
    code: str
    message: str


class AnalysisWarning(StrictModel):
    code: str
    severity: Literal["low", "medium", "high"] = Field(
        ..., description="Важность замечания для проверки данных; не кредитный риск заявителя")
    message: str
    fields: list[str]


class Readiness(StrictModel):
    annual_model: bool
    monthly_cash_flow: bool
    next_month_receipts_and_operating_payments: bool
    balance_after_all_debt: bool
    dscr: bool
    debt_to_ebitda: bool
    collateral_valuation: bool


class ApplicationSummary(StrictModel):
    application_id: str | int | None
    document_version: int | None
    borrower_inn: str | None
    loan_type: str | None
    loan_amount_rub: float | None
    term_months: int | None
    annual_rate_percent: float | None
    has_collateral: bool
    analysis_date: date


class ModelOutputs(StrictModel):
    status: Literal["not_run", "completed", "failed"]
    forecast_revenue_rub_thousands: float | None
    safe_credit_limit_rub_thousands: float | None
    net_margin_percent: float | None
    operating_margin_percent: float | None
    loss_probability_percent: float | None
    liquidity_crisis_probability_percent: float | None
    default_probability_percent: float | None
    approval_probability_percent: float | None
    risk_grade: str | None
    decision: str | None
    operating_cash_flow_forecast_rub: float | None
    note: str


class AnalystResult(StrictModel):
    model_audit: dict | None = None
    schema_version: Literal[2] = 2
    application: ApplicationSummary
    annual_model_input: AnnualInput
    cash_flow: CashFlowOutput
    statistics: dict[str, Statistic]
    next_month_forecast: ForecastOutput
    model_outputs: ModelOutputs
    document_fields: list[DocumentField]
    client_requests: list[ClientRequest]
    employee_recommendations: list[Recommendation]
    warnings: list[AnalysisWarning]
    readiness: Readiness
    is_mock: bool
