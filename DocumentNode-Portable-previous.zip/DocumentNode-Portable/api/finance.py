"""Source-aware financial preparation. No credit decisions or ML inference here."""
import calendar
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
from statistics import mean

from finance_schema import AnalystResult, ApplicationContext, FinancialData, Observation, Source

ANNUAL_FIELDS = (
    "revenue", "net_profit_current", "operating_profit_current", "total_assets", "equity",
    "current_assets", "short_term_liabilities", "cash", "receivables", "okved_group",
)
FLOW_FIELDS = {"revenue", "net_profit_current", "operating_profit_current"}
MONTH_FIELDS = ("opening_balance", "closing_balance", "inflows", "outflows", "customer_receipts", "operating_payments", "debt_service")
WARNING_SEVERITIES = {
    "subject_mismatch": "high", "period_mismatch": "medium",
    "invalid_value": "medium", "invalid_okved": "medium",
    "conflicting_metrics": "high", "conflicting_cash_month": "high",
    "unexpected_accounts": "high", "balance_not_reconciled": "high",
    "classification_error": "high", "incomplete_debt_payment": "high",
    "conflicting_debt_schedule": "high", "debt_confirmation_conflict": "high",
    "unsupported_forecast_horizon": "medium", "stale_bank_history": "medium",
    "seasonality_not_estimated": "low", "mock_data": "high",
}


def money(value, unit, output="RUB"):
    if value is None:
        return None
    factor = Decimal(1000) if unit == "RUB_THOUSANDS" else Decimal(1)
    if output == "RUB_THOUSANDS":
        factor /= Decimal(1000)
    precision = Decimal("0.00001") if output == "RUB_THOUSANDS" else Decimal("0.01")
    return float((Decimal(str(value)) * factor).quantize(precision))


def end_of_month(month):
    first = date.fromisoformat(month + "-01")
    return first.replace(day=calendar.monthrange(first.year, first.month)[1])


def next_month(month):
    return (end_of_month(month) + timedelta(days=1)).strftime("%Y-%m")


def safe_ratio(numerator, denominator):
    return round(numerator / denominator, 6) if numerator is not None and denominator is not None and denominator > 0 else None


def prepare_financial_analysis(context, data=None):
    context = ApplicationContext.model_validate(context)
    data = FinancialData.model_validate(data or {})
    combined = FinancialData(**{key: getattr(context.financial_data, key) + getattr(data, key)
                                for key in FinancialData.model_fields})
    for report in context.provider_reports:
        for field, value in report.metrics.items():
            combined.annual_metrics.append(Observation(
                field=field, value=value, unit="CODE" if field == "okved_group" else report.unit,
                period_start=report.period_start, period_end=report.period_end, as_of=report.as_of,
                subject_inn=report.organization.inn,
                source=Source(provider=report.provider, locator=f"metrics.{field}", is_mock=report.is_mock)))
    warnings, requests, recommendations = [], [], []

    def warn(code, message, fields=None):
        item = {"code": code, "severity": WARNING_SEVERITIES[code], "message": message, "fields": fields or []}
        if item not in warnings:
            warnings.append(item)

    def request(code, title, document, fields, required_for, priority="required"):
        requests.append({"code": code, "title": title, "message": document,
                         "fields": fields, "required_for": required_for,
                         "priority": priority, "action": "upload_or_clarify"})

    subjects = {obs.subject_inn for obs in combined.annual_metrics if obs.subject_inn}
    subject = context.borrower_inn or (next(iter(subjects)) if len(subjects) == 1 else None)
    ambiguous_subject = not context.borrower_inn and len(subjects) > 1
    if ambiguous_subject:
        warn("subject_mismatch", "В источниках несколько ИНН; укажите borrower_inn. Годовые значения не объединены")

    # Select one reporting year. Never combine annual flows and balances from different years.
    candidates = [o.period_end.year for o in combined.annual_metrics
                  if o.period_end and o.period_end <= context.analysis_date and o.field in FLOW_FIELDS
                  and o.period_start == date(o.period_end.year, 1, 1)
                  and o.period_end == date(o.period_end.year, 12, 31)]
    year = context.reporting_year or (max(candidates) if candidates else None)
    period_start = date(year, 1, 1) if year else None
    period_end = date(year, 12, 31) if year else None
    metrics = dict.fromkeys(ANNUAL_FIELDS)
    sources = {key: [] for key in ANNUAL_FIELDS}
    by_field = defaultdict(list)
    for obs in combined.annual_metrics:
        if obs.value is None:
            continue
        if ambiguous_subject or subject and obs.subject_inn and obs.subject_inn != subject:
            warn("subject_mismatch", "Показатель другого лица исключён", [obs.field])
            continue
        if obs.field != "okved_group":
            matched = (obs.period_start == period_start and obs.period_end == period_end) if obs.field in FLOW_FIELDS else (obs.as_of == period_end)
            if not year or not matched or period_end > context.analysis_date:
                warn("period_mismatch", "Показатель без нужного периода/даты не включён в годовой набор", [obs.field])
                continue
            value = money(obs.value, obs.unit, "RUB_THOUSANDS")
            if obs.field in {"revenue", "total_assets"} and value <= 0 or obs.field in {"cash", "receivables", "current_assets", "short_term_liabilities"} and value < 0:
                warn("invalid_value", "Значение не удовлетворяет входному контракту модели", [obs.field])
                continue
        else:
            value = str(obs.value)[:2]
            if len(value) != 2 or not value.isascii() or not value.isdigit():
                warn("invalid_okved", "Основной ОКВЭД не распознан как двухзначная группа", [obs.field])
                continue
        by_field[obs.field].append((value, obs.source.model_dump(mode="json")))
    for field, observations in by_field.items():
        values = {value for value, _ in observations}
        sources[field] = [source for _, source in observations]
        if len(values) == 1:
            metrics[field] = observations[0][0]
        else:
            warn("conflicting_metrics", "Источники дают разные значения; показатель не выбран автоматически", [field])
    for fields, invalid in (
        (("current_assets", "total_assets"), metrics["current_assets"] is not None and metrics["total_assets"] is not None and metrics["current_assets"] > metrics["total_assets"]),
        (("cash", "receivables", "current_assets"), all(metrics[key] is not None for key in ("cash", "receivables", "current_assets")) and metrics["cash"] + metrics["receivables"] > metrics["current_assets"]),
    ):
        if invalid:
            warn("conflicting_metrics", "Состав активов противоречит итогам; значения требуют сверки", list(fields))
            for field in fields:
                metrics[field] = None
    missing = [key for key, value in metrics.items() if value is None]
    if missing:
        request("annual_metrics_missing", "Дополнить годовые показатели",
                "Предоставьте баланс и отчёт о финансовых результатах за один год с единицами измерения; для ИП — управленческий отчёт и анкету активов/обязательств. Для ОКВЭД — сведения реестра. Уточните отмеченные поля, если документы уже загружены.",
                missing, ["annual_model"])

    # One monthly total per account; identical reuploads do not double the amounts.
    grouped, conflicted = {}, set()
    for month in combined.cash_flow_months:
        key = (month.account_id, month.month)
        row = {field: money(getattr(month, field), month.unit) for field in MONTH_FIELDS}
        row.update(account_id=month.account_id, month=month.month,
                   coverage_start=month.coverage_start.isoformat(), coverage_end=month.coverage_end.isoformat(),
                   complete_month=month.complete_month,
                   customer_breakdown=[{"counterparty_id": item.counterparty_id,
                                        "amount": money(item.amount, month.unit)} for item in month.customer_breakdown])
        if key in grouped and grouped[key][0] != row:
            conflicted.add(key)
            warn("conflicting_cash_month", "Несовпадающие месячные данные одного счёта исключены", [str(key)])
        else:
            grouped.setdefault(key, (row, []))[1].append(month.source.model_dump(mode="json"))
    expected = set(context.expected_account_ids)
    observed = {account for account, _ in grouped}
    accounts_confirmed = bool(expected) and observed <= expected
    if not expected:
        recommendations.append({"code": "confirm_bank_accounts", "message": "Подтвердите список всех расчётных счетов в expected_account_ids; без него полнота денежного потока не подтверждена."})
    elif observed - expected:
        warn("unexpected_accounts", "В выписках есть счета вне подтверждённого списка")
    monthly = []
    for month in sorted({month for _, month in grouped}):
        month_end = end_of_month(month)
        rows = [(account, row, src) for (account, m), (row, src) in grouped.items() if m == month]
        full = accounts_confirmed and {account for account, _, _ in rows} == expected and month_end <= context.analysis_date
        for account, row, _ in rows:
            full = full and (account, month) not in conflicted and row["complete_month"] and row["coverage_start"] == month + "-01" and row["coverage_end"] == month_end.isoformat()
            if all(row[field] is not None for field in ("opening_balance", "closing_balance", "inflows", "outflows")):
                if abs(row["opening_balance"] + row["inflows"] - row["outflows"] - row["closing_balance"]) > .02:
                    full = False
                    warn("balance_not_reconciled", "Начальный остаток + поступления − списания не совпадают с конечным остатком", [account, month])
            else:
                full = False
            if row["customer_receipts"] is not None and row["inflows"] is not None and row["customer_receipts"] > row["inflows"] + .02:
                full = False
                warn("classification_error", "Поступления покупателей превышают все поступления", [account, month])
            if row["outflows"] is not None and row["operating_payments"] is not None and row["debt_service"] is not None and row["operating_payments"] + row["debt_service"] > row["outflows"] + .02:
                full = False
                warn("classification_error", "Операционные и долговые платежи превышают все списания", [account, month])
        aggregate = {"month": month, "complete": bool(full), "unit": "RUB",
                     "accounts": [account for account, _, _ in rows],
                     "sources": [source for _, _, src in rows for source in src]}
        for field in MONTH_FIELDS:
            aggregate[field] = round(sum(row[field] for _, row, _ in rows), 2) if all(row[field] is not None for _, row, _ in rows) else None
        breakdown = defaultdict(float)
        classified = True
        for _, row, _ in rows:
            if row["customer_receipts"] is None or abs(sum(item["amount"] for item in row["customer_breakdown"]) - row["customer_receipts"]) > .02:
                classified = False
            for item in row["customer_breakdown"]:
                breakdown[item["counterparty_id"]] += item["amount"]
        aggregate["customer_breakdown"] = dict(breakdown) if classified else None
        monthly.append(aggregate)
    full_months = [row for row in monthly if row["complete"]]
    recent = full_months[-3:]
    consecutive = len(recent) == 3 and all(next_month(recent[i]["month"]) == recent[i + 1]["month"] for i in range(2))
    required_cash = ("customer_receipts", "operating_payments", "closing_balance")
    history_ready = consecutive and all(row[field] is not None for row in recent for field in required_cash)
    if not history_ready:
        request("bank_history_missing", "Дополнить историю денежного потока",
                "Загрузите полные выписки по всем расчётным счетам минимум за 3 последовательных полных месяца (желательно 12). Нужны даты, суммы, направления, остатки и классификация поступлений покупателей, операционных платежей и переводов между своими счетами.",
                list(required_cash), ["monthly_cash_flow", "next_month_forecast"])

    # Debt schedule is separate from bank outflows: do not charge the same payment twice.
    debts, debt_conflicts = {}, False
    for payment in combined.debt_payments:
        key = (payment.loan_id, payment.due_date)
        parts = (payment.principal, payment.interest, payment.fees)
        parts_total = sum(parts) if all(part is not None for part in parts) else None
        total = payment.total_payment if payment.total_payment is not None else parts_total
        if total is None or payment.total_payment is not None and parts_total is not None and abs(money(payment.total_payment, payment.unit) - money(parts_total, payment.unit)) > .02:
            debt_conflicts = True
            warn("incomplete_debt_payment", "Общий платёж неизвестен или не совпадает с суммой основного долга, процентов и комиссий")
            continue
        value = money(total, payment.unit)
        if key in debts and debts[key]["amount"] != value:
            debt_conflicts = True
            warn("conflicting_debt_schedule", "Графики дают разные платежи по одному кредиту и дате")
        debts[key] = {"loan_id": payment.loan_id, "date": payment.due_date.isoformat(),
                      "amount": value, "source": payment.source.model_dump(mode="json")}
    if context.no_existing_debt_confirmed and debts:
        debt_conflicts = True
        warn("debt_confirmation_conflict", "Подтверждение отсутствия долгов противоречит графикам")

    def debt_total(start, end):
        if debt_conflicts:
            return None
        if context.no_existing_debt_confirmed:
            return 0.0
        if not (context.debt_schedule_complete and context.debt_schedule_start and context.debt_schedule_end
                and context.debt_schedule_start <= start and context.debt_schedule_end >= end):
            return None
        return round(sum(item["amount"] for item in debts.values() if start.isoformat() <= item["date"] <= end.isoformat()), 2)

    horizon = context.forecast_month or next_month(context.analysis_date.strftime("%Y-%m"))
    horizon_start = date.fromisoformat(horizon + "-01") if horizon else None
    horizon_end = end_of_month(horizon) if horizon else None
    current_month = context.analysis_date.strftime("%Y-%m")
    last_closed = current_month if context.analysis_date == end_of_month(current_month) else (date.fromisoformat(current_month + "-01") - timedelta(days=1)).strftime("%Y-%m")
    fresh = bool(recent) and recent[-1]["month"] == last_closed
    projection_months = []
    if recent:
        cursor = next_month(recent[-1]["month"])
        while cursor <= horizon and len(projection_months) < 3:
            projection_months.append(cursor)
            cursor = next_month(cursor)
    valid_horizon = bool(projection_months) and len(projection_months) <= 2 and projection_months[-1] == horizon
    if not valid_horizon and history_ready:
        warn("unsupported_forecast_horizon", "Базовый прогноз поддерживает не более двух месяцев после последнего наблюдения")
    if history_ready and not fresh:
        warn("stale_bank_history", "Последняя полная выписка устарела: прогноз не относится к ближайшему месяцу")
        request("fresh_statement_needed", "Предоставить свежую выписку", "Загрузите выписки до последнего завершённого месяца; старую историю нельзя выдавать за текущий прогноз.", [], ["next_month_forecast"])
    next_debt = debt_total(horizon_start, horizon_end) if horizon else None
    debts_known = valid_horizon and all(debt_total(date.fromisoformat(month + "-01"), end_of_month(month)) is not None for month in projection_months)
    if not debts_known:
        request("debt_schedule_missing", "Уточнить обязательные кредитные платежи",
                "Предоставьте графики всех действующих кредитов/лизинга с датами, основным долгом, процентами и комиссиями на прогнозный период либо подтвердите отсутствие долгов.",
                ["debt_payments"], ["balance_after_debt", "cash_gap_scenario"])
    if context.proposed_monthly_payment_rub is None:
        recommendations.append({"code": "proposed_credit_payment_missing", "message": "Передайте proposed_monthly_payment_rub из расчёта банка. Без него остаток после запрашиваемого кредита не определяется."})

    # Additional ratios only if genuinely sourced and period-aligned.
    def fact(field, flow=False):
        values = []
        for obs in combined.supplemental_metrics:
            if obs.field != field:
                continue
            matched = obs.period_start == period_start and obs.period_end == period_end if flow else obs.as_of == period_end
            if matched and year and period_end <= context.analysis_date:
                values.append(money(obs.value, obs.unit))
        return values[0] if values and len(set(values)) == 1 else None

    ebitda, debt, cfads = fact("ebitda", True), fact("total_debt"), fact("cfads", True)
    annual_debt_service = debt_total(period_start, period_end) if year else None
    collateral = [obs for obs in combined.supplemental_metrics if obs.field == "collateral_value" and obs.as_of and obs.as_of <= context.analysis_date]
    latest_valuation = max((obs.as_of for obs in collateral), default=None)
    valuations = {money(obs.value, obs.unit) for obs in collateral if obs.as_of == latest_valuation}
    collateral_value = next(iter(valuations)) if len(valuations) == 1 else None
    if ebitda is None or debt is None:
        request("debt_to_ebitda_inputs_missing", "Данные для Долг/EBITDA",
                "Для долговой нагрузки нужны совокупный долг на отчётную дату и подтверждённый расчёт EBITDA за тот же год; прибыль от продаж не заменяет EBITDA.",
                ["total_debt", "ebitda"], ["debt_to_ebitda"], "optional")
    if cfads is None or annual_debt_service is None:
        request("dscr_inputs_missing", "Данные для DSCR",
                "Для DSCR предоставьте денежный поток, доступный для обслуживания долга (CFADS), и полный график обслуживания долга за тот же период.",
                ["cfads", "debt_service"], ["dscr"], "optional")
    if context.has_collateral and collateral_value is None:
        request("collateral_valuation_missing", "Оценка обеспечения",
                "Предоставьте оценочный отчёт с датой и стоимостью обеспечения; право собственности само по себе не подтверждает оценочную стоимость.",
                ["collateral_value"], ["collateral_valuation"])
    stat_values = {
        "current_ratio": safe_ratio(metrics["current_assets"], metrics["short_term_liabilities"]),
        "cash_ratio": safe_ratio(metrics["cash"], metrics["short_term_liabilities"]),
        "equity_to_assets": safe_ratio(metrics["equity"], metrics["total_assets"]),
        "net_margin": safe_ratio(metrics["net_profit_current"], metrics["revenue"]),
        "operating_margin": safe_ratio(metrics["operating_profit_current"], metrics["revenue"]),
        "debt_to_ebitda": safe_ratio(debt, ebitda), "dscr": safe_ratio(cfads, annual_debt_service),
        "collateral_value_rub": collateral_value,
    }
    formulas = {"current_ratio": "current_assets / short_term_liabilities", "cash_ratio": "cash / short_term_liabilities",
                "equity_to_assets": "equity / total_assets", "net_margin": "net_profit_current / revenue",
                "operating_margin": "operating_profit_current / revenue", "debt_to_ebitda": "total_debt / ebitda",
                "dscr": "cfads / debt_service_same_period", "collateral_value_rub": "latest sourced valuation"}
    statistics = {key: {"value": value, "unit": "RUB" if key == "collateral_value_rub" else "ratio",
                        "formula": formulas[key], "status": "available" if value is not None else "unavailable",
                        "reason": None if value is not None else "Нет согласованных входов либо знаменатель неположительный"}
                  for key, value in stat_values.items()}
    forecast_ready = history_ready and fresh and valid_horizon
    scenarios = []
    if forecast_ready:
        receipts = round(mean(row["customer_receipts"] for row in recent), 2)
        operating = round(mean(row["operating_payments"] for row in recent), 2)
        observed_opening = recent[-1]["closing_balance"]
        for name, receipts_factor, operating_factor in (("base", 1., 1.), ("cautious", .9, 1.1), ("stress", .8, 1.2)):
            incoming, outgoing = round(receipts * receipts_factor, 2), round(operating * operating_factor, 2)
            cash_balance = observed_opening
            path = []
            for month in projection_months:
                payment = debt_total(date.fromisoformat(month + "-01"), end_of_month(month))
                proposed = context.proposed_monthly_payment_rub if month == horizon else 0.
                opening = cash_balance
                balance_existing = round(opening + incoming - outgoing - payment, 2) if opening is not None and payment is not None else None
                balance_all = round(balance_existing - proposed, 2) if balance_existing is not None and proposed is not None else None
                path.append({"month": month, "opening_balance_rub": opening,
                             "customer_receipts_rub": incoming, "operating_payments_rub": outgoing,
                             "existing_debt_service_rub": payment, "proposed_credit_payment_rub": proposed,
                             "closing_balance_rub": balance_all})
                cash_balance = balance_all
            scenarios.append({"name": name, "assumptions": {"receipts_factor": receipts_factor, "operating_payments_factor": operating_factor},
                              "customer_receipts_rub": incoming, "operating_payments_rub": outgoing,
                              "existing_debt_service_rub": next_debt,
                              "proposed_credit_payment_rub": context.proposed_monthly_payment_rub,
                              "starting_observed_balance_rub": observed_opening,
                              "opening_balance_rub": opening, "balance_after_existing_debt_rub": balance_existing,
                              "balance_after_all_debt_rub": balance_all,
                              "cash_gap_rub": max(0., -balance_all) if balance_all is not None else None,
                              "projection_path": path})
    # Rolling-origin backtest; no fictional confidence intervals or probabilities.
    errors = []
    lead = len(projection_months) if valid_horizon else 1
    for index in range(3, len(full_months) - lead + 1):
        window = full_months[index - 3:index + lead]
        if all(next_month(window[i]["month"]) == window[i + 1]["month"] for i in range(len(window) - 1)) and all(row["customer_receipts"] is not None for row in window):
            expected_receipts = mean(row["customer_receipts"] for row in window[:3])
            actual = window[-1]["customer_receipts"]
            errors.append({"month": window[-1]["month"], "absolute_error_rub": round(abs(expected_receipts - actual), 2),
                           "absolute_percentage_error": abs(expected_receipts - actual) / actual * 100 if actual > 0 else None})
    backtest = {"folds": len(errors), "mae_rub": round(mean(e["absolute_error_rub"] for e in errors), 2) if errors else None,
                "mape_percent": round(mean(e["absolute_percentage_error"] for e in errors), 2) if errors and all(e["absolute_percentage_error"] is not None for e in errors) else None}
    warn("seasonality_not_estimated", "Базовый прогноз не моделирует годовую сезонность; для её отдельной проверки нужна история минимум за 24 последовательных полных месяца")
    concentration = None
    if full_months and all(row["customer_breakdown"] is not None for row in full_months):
        totals = defaultdict(float)
        for row in full_months:
            for counterparty, amount in row["customer_breakdown"].items():
                totals[counterparty] += amount
        concentration = safe_ratio(max(totals.values(), default=0.), sum(totals.values()))
    if concentration is None:
        recommendations.append({"code": "customer_concentration_unavailable", "message": "Для концентрации покупателей нужна полная расшифровка поступлений по контрагентам; долю в выручке по одной выписке не утверждать."})
    statistics["largest_customer_receipts_share"] = {"value": concentration, "unit": "ratio",
        "formula": "largest counterparty customer receipts / all classified customer receipts", "status": "available" if concentration is not None else "unavailable"}
    statistics["dscr"]["inputs"] = {"cfads_rub": cfads, "debt_service_rub": annual_debt_service,
        "period_start": period_start.isoformat() if year else None, "period_end": period_end.isoformat() if year else None}
    statistics["debt_to_ebitda"]["inputs"] = {"total_debt_rub": debt, "ebitda_rub": ebitda}
    for key, facts in (("dscr", {"cfads"}), ("debt_to_ebitda", {"total_debt", "ebitda"}), ("collateral_value_rub", {"collateral_value"})):
        statistics[key]["sources"] = [obs.source.model_dump(mode="json") for obs in combined.supplemental_metrics
            if obs.field in facts and (obs.as_of == latest_valuation if key == "collateral_value_rub" else
                obs.period_start == period_start and obs.period_end == period_end if obs.field in {"cfads", "ebitda"} else obs.as_of == period_end)]
    statistics["dscr"]["sources"].extend(payment.source.model_dump(mode="json") for payment in combined.debt_payments
        if period_start and period_start <= payment.due_date <= period_end)
    all_sources = [o.source for field in FinancialData.model_fields for o in getattr(combined, field)]
    is_mock = any(source.is_mock or (source.provider or "").startswith("mock") for source in all_sources)
    if is_mock:
        warn("mock_data", "В наборе есть демонстрационные данные; не использовать как реальные сведения клиента")
    if data.annual_metrics or data.cash_flow_months or data.supplemental_metrics:
        recommendations.append({"code": "verify_extraction", "message": "Сверьте извлечённые показатели с указанными источниками; автоматическое извлечение не подтверждает подлинность документов."})
    result = {
        "schema_version": 2,
        "application": {"application_id": context.application_id, "document_version": context.document_version,
                        "borrower_inn": subject, "loan_type": context.loan_type,
                        "loan_amount_rub": context.loan_amount_rub, "term_months": context.term_months,
                        "annual_rate_percent": context.annual_rate_percent,
                        "has_collateral": context.has_collateral, "analysis_date": context.analysis_date.isoformat()},
        "annual_model_input": {"metrics": metrics, "unit": "RUB_THOUSANDS", "currency": "RUB",
                               "period_start": period_start.isoformat() if year else None,
                               "period_end": period_end.isoformat() if year else None,
                               "as_of": period_end.isoformat() if year else None,
                               "ready": not missing, "missing_fields": missing, "sources": sources},
        "cash_flow": {"unit": "RUB", "currency": "RUB", "months": monthly,
                      "complete_months": len(full_months), "accounts_confirmed": accounts_confirmed,
                      "average_monthly_inflows_rub": round(mean(row["inflows"] for row in full_months), 2) if full_months else None,
                      "average_monthly_outflows_rub": round(mean(row["outflows"] for row in full_months), 2) if full_months else None,
                      "average_month_end_balance_rub": round(mean(row["closing_balance"] for row in full_months), 2) if full_months else None,
                      "latest_observed_balance_rub": full_months[-1]["closing_balance"] if full_months else None,
                      "latest_observed_balance_date": end_of_month(full_months[-1]["month"]).isoformat() if full_months else None},
        "statistics": statistics,
        "next_month_forecast": {"ready": forecast_ready, "period": horizon, "unit": "RUB",
                                "forecast_as_of": context.analysis_date.isoformat(),
                                "data_as_of": end_of_month(recent[-1]["month"]).isoformat() if recent else None,
                                "horizon_months_after_last_observation": len(projection_months) if valid_horizon else None,
                                "method": "mean_last_3_complete_consecutive_months", "scenarios": scenarios,
                                "backtest": backtest, "cash_gap_probability": None, "confidence_interval": None,
                                "limitations": ["Сценарии — заданные изменения ±10/20%, а не вероятности или доверительные интервалы",
                                                "Учитываются поступления покупателей, операционные платежи и известные платежи по долгу; иные будущие потоки предполагаются нулевыми",
                                                "До целевого месяца строится помесячный мост от последнего остатка; неполный текущий месяц не выдаётся за фактический. Платёж по новому кредиту применяется только в целевом месяце",
                                                "Конечный месячный остаток не исключает внутримесячный кассовый разрыв",
                                                "Банковские поступления не равны бухгалтерской выручке"]},
        "model_outputs": {"status": "not_run", "forecast_revenue_rub_thousands": None,
                          "safe_credit_limit_rub_thousands": None, "net_margin_percent": None,
                          "operating_margin_percent": None, "loss_probability_percent": None,
                          "liquidity_crisis_probability_percent": None, "default_probability_percent": None,
                          "approval_probability_percent": None, "risk_grade": None,
                          "decision": None, "operating_cash_flow_forecast_rub": None,
                          "note": "Годовые модели запускаются отдельно по annual_model_input.metrics; вероятность убытка/дефицита ликвидности не является вероятностью дефолта или одобрения. Прогноз операционного потока требует собственной модели и истории."},
        "document_fields": [item.model_dump(mode="json") for item in combined.document_fields],
        "client_requests": requests, "employee_recommendations": recommendations,
        "warnings": warnings,
        "readiness": {"annual_model": not missing, "monthly_cash_flow": bool(full_months),
                      "next_month_receipts_and_operating_payments": forecast_ready,
                      "balance_after_all_debt": forecast_ready and debts_known and context.proposed_monthly_payment_rub is not None,
                      "dscr": stat_values["dscr"] is not None, "debt_to_ebitda": stat_values["debt_to_ebitda"] is not None,
                      "collateral_valuation": collateral_value is not None},
        "is_mock": is_mock,
    }
    return AnalystResult.model_validate(result).model_dump(mode="json")
