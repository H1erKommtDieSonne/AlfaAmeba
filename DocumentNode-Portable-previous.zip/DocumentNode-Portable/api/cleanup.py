import json
import os
import re
import time
import shutil
from pathlib import Path

from redis import Redis
from rq.job import Job
from rq.exceptions import NoSuchJobError

ROOT = Path("/data/jobs")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")

RAW_TTL = 24 * 3600
RESULT_TTL = 7 * 24 * 3600
FAILED_TTL = 7 * 24 * 3600
INTERVAL = 3600

ACTIVE = {"queued", "started", "deferred", "scheduled"}


def cleanup():
    redis = Redis.from_url(REDIS_URL)
    redis.ping()

    now = time.time()

    if not ROOT.exists():
        return

    for folder in ROOT.iterdir():
        if (
            folder.is_symlink()
            or not folder.is_dir()
            or not re.fullmatch(r"[0-9a-f]{32}", folder.name)
        ):
            continue

        result_file = folder / "result.json"
        callback_file = folder / "callback.json"
        manifest_file = folder / "manifest.json"

        try:
            job = Job.fetch(
                folder.name,
                connection=redis,
                serializer="json"
            )
            status = job.get_status(refresh=True)
            status = getattr(status, "value", str(status))
        except NoSuchJobError:
            status = "missing"

        if status in ACTIVE:
            continue

        if result_file.is_file():
            if (folder / "feedback.json").is_file() and os.getenv("CALLBACK_URL", "").strip():
                receipt_path = folder / "feedback-receipt.json"
                if not receipt_path.is_file():
                    continue
                receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
                if not receipt.get("delivered"):
                    continue
            if os.getenv("CALLBACK_URL", "").strip() and not callback_file.is_file():
                continue

            result_age = now - result_file.stat().st_mtime

            # Удаляем исходные документы
            if result_age >= RAW_TTL:
                if manifest_file.is_file():
                    manifest = json.loads(
                        manifest_file.read_text(encoding="utf-8")
                    )

                    for item in manifest.get("files", []):
                        name = item.get("stored_name", "")

                        if not re.fullmatch(
                            r"document_\d+\.[a-z0-9]+", name
                        ):
                            continue

                        path = folder / name

                        if path.is_file() and not path.is_symlink():
                            path.unlink()
                            print("Удалён исходник:", path, flush=True)

            # Не удаляем результат до подтверждения callback
            callback_required = bool(
                os.getenv("CALLBACK_URL", "").strip()
            )

            if callback_required and not callback_file.is_file():
                continue

            last_update = max(
                result_file.stat().st_mtime,
                callback_file.stat().st_mtime
                if callback_file.is_file() else 0
            )

            if now - last_update >= RESULT_TTL:
                shutil.rmtree(folder)
                print("Удалено завершённое задание:", folder.name, flush=True)

        elif status in {"failed", "missing", "canceled", "stopped"}:
            age = now - folder.stat().st_mtime

            if age >= FAILED_TTL:
                shutil.rmtree(folder)
                print("Удалено старое задание:", folder.name, flush=True)


if __name__ == "__main__":
    print("Cleanup service started", flush=True)

    while True:
        try:
            cleanup()
        except Exception as e:
            print("Cleanup error:", str(e), flush=True)

        time.sleep(INTERVAL)
