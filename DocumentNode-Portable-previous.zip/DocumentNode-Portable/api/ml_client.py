"""Run annual inference before persisting a document job's immutable callback."""
import os
from datetime import date
import httpx
from finance_schema import ModelOutputs


def enrich_with_models(analysis):
    if os.getenv('ML_NODE_ENABLED', 'true').lower() in {'false', '0', 'no'}:
        return
    annual = analysis['annual_model_input']
    if not (analysis['readiness']['annual_model'] and annual['ready'] and not annual['missing_fields']):
        return
    url = os.getenv('ML_NODE_URL', '').strip()
    if not url:
        return
    application = analysis['application']
    params = {'is_mock': str(bool(analysis['is_mock'])).lower()}
    for field in ('application_id', 'document_version'):
        if application.get(field) is not None:
            params[field] = str(application[field])
    if annual.get('period_end'):
        params['reporting_year'] = str(date.fromisoformat(str(annual['period_end'])).year)
    try:
        if annual['unit'] != 'RUB_THOUSANDS':
            raise ValueError('Invalid model input unit')
        with httpx.Client(timeout=float(os.getenv('ML_NODE_TIMEOUT_SECONDS', '15')), trust_env=False, follow_redirects=False) as client:
            response = client.post(url.rstrip('/') + '/v1/predict', json=annual['metrics'], params=params,
                                   headers={'X-API-Key': os.getenv('ML_NODE_API_KEY', '')})
        response.raise_for_status()
        result = response.json()
        if result.get('schema_version') != 1 or result.get('input_unit') != 'RUB_THOUSANDS':
            raise ValueError('Unsupported ML response')
        for field in ('application_id', 'document_version'):
            if str(result.get(field)) != str(application.get(field)):
                raise ValueError('ML application/version mismatch')
        if result.get('is_mock') != bool(analysis['is_mock']):
            raise ValueError('ML mock attribution mismatch')
        outputs = ModelOutputs.model_validate(result['model_outputs'])
        if outputs.status != 'completed':
            raise ValueError('Incomplete ML response')
        warnings = result.get('warnings', [])
        from finance_schema import AnalysisWarning
        warnings = [AnalysisWarning.model_validate({**w, 'fields': []}).model_dump() for w in warnings]
        analysis['model_outputs'] = outputs.model_dump()
        analysis['model_audit'] = result
        analysis['warnings'].extend(warnings)
    except Exception:
        # Keep documented facts and missing-document requests, never convert failure into approval.
        analysis['model_outputs']['status'] = 'failed'
        analysis['model_outputs']['note'] = 'Техническая ошибка ML анализа. Нужна новая попытка анализа; документы и коэффициенты сохранены.'
        analysis['warnings'].append({'code': 'ml_inference_failed', 'severity': 'high', 'message': 'Годовой ML анализ не выполнен: проверьте доступность сервиса и запустите новую попытку.', 'fields': []})
