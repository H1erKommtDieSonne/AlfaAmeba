"""Deterministic parser for the documented bank transaction CSV contract."""
import csv
import io
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

from finance import end_of_month
from finance_schema import ApplicationContext, CashMonth, FinancialData, Source

COLUMNS = {"transaction_id", "account_id", "date", "direction", "amount", "currency", "category", "counterparty_id"}
IN_CATEGORIES = {"customer_receipt", "internal_transfer", "loan_received", "other_inflow"}
OUT_CATEGORIES = {"operating_payment", "debt_principal", "debt_interest", "debt_fee", "internal_transfer", "capital_expenditure", "other_outflow"}


def parse_bank_csv(filename, content, context):
    """Return None for other CSV formats; never guess transaction categories."""
    text = content.decode("utf-8-sig")
    if not text.strip():
        return None
    delimiter = ";" if ";" in text.splitlines()[0] else ","
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not COLUMNS <= set(reader.fieldnames or []):
        return None
    context = ApplicationContext.model_validate(context)
    records, seen = defaultdict(list), {}
    for line, row in enumerate(reader, 2):
        if line > 100002:
            raise ValueError("В CSV более 100000 операций")
        if any(row.get(field) is None for field in COLUMNS):
            raise ValueError(f"Неполная строка CSV {line}")
        try:
            amount = Decimal(row["amount"])
            transaction_date = date.fromisoformat(row["date"])
        except (InvalidOperation, ValueError):
            raise ValueError(f"Неверная дата или сумма CSV, строка {line}")
        if not amount.is_finite() or amount < 0 or amount.as_tuple().exponent < -2:
            raise ValueError(f"Нужна неотрицательная сумма в рублях с точностью до копейки, строка {line}")
        categories = IN_CATEGORIES if row["direction"] == "in" else OUT_CATEGORIES if row["direction"] == "out" else set()
        if row["currency"] != "RUB" or row["category"] not in categories:
            raise ValueError(f"Неизвестное направление/категория или валюта, строка {line}")
        if not row["account_id"] or not row["transaction_id"]:
            raise ValueError(f"Нужны account_id и transaction_id, строка {line}")
        key = (row["account_id"], row["transaction_id"])
        signature = (transaction_date, amount, row["direction"], row["category"], row["counterparty_id"])
        if key in seen:
            if seen[key] != signature:
                raise ValueError(f"Конфликтующий transaction_id, строка {line}")
            continue
        seen[key] = signature
        records[row["account_id"]].append((transaction_date, amount, row))
    for period in context.statement_periods:
        if period.filename == filename:
            records.setdefault(period.account_id, [])
    months = []
    for account, transactions in records.items():
        periods = [period for period in context.statement_periods if period.filename == filename and period.account_id == account]
        if len(periods) > 1:
            raise ValueError("Для одного файла/счёта нужна одна запись statement_periods")
        period = periods[0] if periods else None
        if period and (period.period_start > period.period_end or any(not period.period_start <= day <= period.period_end for day, _, _ in transactions)):
            raise ValueError("Даты операций не входят в объявленный период выписки")
        total_net = sum((amount if row["direction"] == "in" else -amount for _, amount, row in transactions), Decimal(0))
        reconciled = period is not None and abs(Decimal(str(period.opening_balance_rub)) + total_net - Decimal(str(period.closing_balance_rub))) <= Decimal("0.02")
        month_keys = {day.strftime("%Y-%m") for day, _, _ in transactions}
        if period:
            cursor = period.period_start.replace(day=1)
            while cursor <= period.period_end:
                month_keys.add(cursor.strftime("%Y-%m"))
                cursor = end_of_month(cursor.strftime("%Y-%m")) + timedelta(days=1)
        running = Decimal(str(period.opening_balance_rub)) if period else None
        for month in sorted(month_keys):
            selected = [(amount, row) for day, amount, row in transactions if day.strftime("%Y-%m") == month]
            inflows = sum((amount for amount, row in selected if row["direction"] == "in"), Decimal(0))
            outflows = sum((amount for amount, row in selected if row["direction"] == "out"), Decimal(0))
            customers = sum((amount for amount, row in selected if row["category"] == "customer_receipt"), Decimal(0))
            operating = sum((amount for amount, row in selected if row["category"] == "operating_payment"), Decimal(0))
            debt = sum((amount for amount, row in selected if row["category"] in {"debt_principal", "debt_interest", "debt_fee"}), Decimal(0))
            counterparties = defaultdict(Decimal)
            all_identified = True
            for amount, row in selected:
                if row["category"] == "customer_receipt":
                    if not row["counterparty_id"]:
                        all_identified = False
                    counterparties[row["counterparty_id"]] += amount
            start, end = date.fromisoformat(month + "-01"), end_of_month(month)
            opening = float(running) if running is not None else None
            if running is not None:
                running += inflows - outflows
            months.append(CashMonth(account_id=account, month=month, complete_month=bool(period and period.complete and reconciled and period.period_start <= start and period.period_end >= end),
                                    unit="RUB", currency="RUB",
                                    coverage_start=max(start, period.period_start) if period else start,
                                    coverage_end=min(end, period.period_end) if period else end,
                                    opening_balance=opening, closing_balance=float(running) if running is not None else None,
                                    inflows=float(inflows), outflows=float(outflows), customer_receipts=float(customers),
                                    operating_payments=float(operating), debt_service=float(debt),
                                    customer_breakdown=[{"counterparty_id": key, "amount": float(value)} for key, value in counterparties.items()] if all_identified else [],
                                    source=Source(filename=filename, locator=f"CSV: операции {month}, счёт {account}", quote=text.splitlines()[0])))
    return FinancialData(cash_flow_months=months)
