@echo off
pushd "%~dp0"
docker compose --profile mock --profile ml stop
popd
pause
