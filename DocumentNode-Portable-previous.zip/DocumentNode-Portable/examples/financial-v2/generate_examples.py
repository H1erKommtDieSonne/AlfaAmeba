"""Generate synthetic integration examples without sending jobs or calling an LLM."""
import csv
import copy
import io
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "api"))
from analysis_pipeline import analyze_files
from bank_csv import parse_bank_csv
from finance import prepare_financial_analysis
from finance_schema import AnalystResult, PrepareRequest

OUT = Path(__file__).parent


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def generate():
    organization = json.loads((ROOT / "mock_bo/data/organizations.json").read_text(encoding="utf-8"))["organizations"][0]
    report = organization["reports"][1]
    fields = {"revenue": ("income_statement", "2110"), "net_profit_current": ("income_statement", "2400"),
              "operating_profit_current": ("income_statement", "2200"), "total_assets": ("balance", "1600"),
              "equity": ("balance", "1300"), "current_assets": ("balance", "1200"),
              "short_term_liabilities": ("balance", "1500"), "cash": ("balance", "1250"), "receivables": ("balance", "1230")}
    provider_report = {"provider": "mock-bo", "is_mock": True, "organization": {"inn": organization["inn"]},
                       "currency": "RUB", "unit": "RUB_THOUSANDS", "period_start": report["period_start"],
                       "period_end": report["period_end"], "as_of": report["as_of"],
                       "metrics": {key: report[form][line] for key, (form, line) in fields.items()}}
    provider_report["metrics"]["okved_group"] = organization["okved"][:2]
    rows = [
        ["1", "demo-account-1", "2026-07-10", "in", 1000000, "RUB", "customer_receipt", "buyer-1"],
        ["2", "demo-account-1", "2026-07-11", "in", 10000000, "RUB", "loan_received", "bank"],
        ["3", "demo-account-1", "2026-07-12", "in", 5000000, "RUB", "internal_transfer", "own"],
        ["4", "demo-account-1", "2026-07-13", "out", 500000, "RUB", "operating_payment", "supplier"],
        ["5", "demo-account-1", "2026-07-14", "out", 200000, "RUB", "debt_principal", "bank"],
        ["6", "demo-account-1", "2026-07-15", "out", 5000000, "RUB", "internal_transfer", "own"],
        ["7", "demo-account-1", "2026-08-10", "in", 2000000, "RUB", "customer_receipt", "buyer-1"],
        ["8", "demo-account-1", "2026-08-11", "out", 800000, "RUB", "operating_payment", "supplier"],
        ["9", "demo-account-1", "2026-08-12", "out", 200000, "RUB", "debt_principal", "bank"],
        ["10", "demo-account-1", "2026-09-10", "in", 3000000, "RUB", "customer_receipt", "buyer-1"],
        ["11", "demo-account-1", "2026-09-11", "out", 1000000, "RUB", "operating_payment", "supplier"],
        ["12", "demo-account-1", "2026-09-12", "out", 200000, "RUB", "debt_principal", "bank"],
    ]
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    writer.writerow(["transaction_id", "account_id", "date", "direction", "amount", "currency", "category", "counterparty_id"])
    writer.writerows(rows)
    content = buffer.getvalue().encode("utf-8")
    (OUT / "bank.csv").write_bytes(content)
    context = {"application_id": "demo-125", "document_version": 2, "borrower_inn": organization["inn"],
               "loan_type": "working_capital", "has_collateral": False, "reporting_year": 2025,
               "analysis_date": "2026-10-24", "expected_account_ids": ["demo-account-1"],
               "proposed_monthly_payment_rub": 200000., "debt_schedule_complete": True,
               "debt_schedule_start": "2026-10-01", "debt_schedule_end": "2026-11-30",
               "provider_reports": [provider_report],
               "statement_periods": [{"filename": "bank.csv", "account_id": "demo-account-1",
                                      "period_start": "2026-07-01", "period_end": "2026-09-30",
                                      "opening_balance_rub": 10000000., "closing_balance_rub": 23100000., "complete": True}],
               "financial_data": {"debt_payments": [
                   {"loan_id": "demo-existing-loan", "due_date": f"2026-{month}-15", "principal": 80000., "interest": 20000., "fees": 0., "unit": "RUB",
                    "source": {"provider": "mock-bank", "locator": f"demo payment 2026-{month}", "is_mock": True}}
                   for month in ("10", "11")]}}
    data = parse_bank_csv("bank.csv", content, context)
    request = PrepareRequest(application_context=context, financial_data=data)
    save(OUT / "context.json", context)
    save(OUT / "prepare-request.json", request.model_dump(mode="json"))
    save(OUT / "financial-result.json", prepare_financial_analysis(context, data))
    stale_context = copy.deepcopy(context)
    stale_context["analysis_date"] = "2026-11-24"
    save(OUT / "prepare-request-stale-history.json", PrepareRequest(
        application_context=stale_context, financial_data=data).model_dump(mode="json"))
    save(OUT / "financial-result-stale-history.json", prepare_financial_analysis(stale_context, data))
    node_result = analyze_files([("bank.csv", content)], "Проверь комплект и подготовь данные", context, "http://unused")
    save(OUT / "node-result.json", node_result)
    needs_documents = {**context, "loan_type": "contract", "has_collateral": True}
    save(OUT / "node-result-needs-documents.json", analyze_files([("bank.csv", content)], "", needs_documents, "http://unused"))
    save(ROOT / "docs/schemas/financial-prepare-v2.schema.json", PrepareRequest.model_json_schema())
    save(ROOT / "docs/schemas/financial-result-v2.schema.json", AnalystResult.model_json_schema())
    from main import app
    save(ROOT / "docs/schemas/openapi-v2.json", app.openapi())


if __name__ == "__main__":
    generate()
    print("Generated synthetic financial API v2 examples and JSON Schemas")
