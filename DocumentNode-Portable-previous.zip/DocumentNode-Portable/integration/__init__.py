"""Integration examples for the separately deployed Django project."""
