"""Copy to Django and configure ML_NODE_URL / ML_NODE_API_KEY (httpx required)."""
import copy
from datetime import date

import httpx


class MLNodeError(RuntimeError):
    pass


class MLNodeClient:
    def __init__(self, base_url, api_key, timeout=15., allow_mock=False):
        self.url = base_url.rstrip("/") + "/v1/predict"
        self.api_key, self.timeout, self.allow_mock = api_key, timeout, allow_mock

    def predict_financial_analysis(self, financial):
        if not financial or not financial.get("readiness", {}).get("annual_model"):
            raise MLNodeError("Annual financial input is not ready")
        annual = financial["annual_model_input"]
        if annual.get("unit") != "RUB_THOUSANDS":
            raise MLNodeError("Expected annual input in thousands of RUB")
        if financial.get("is_mock") and not self.allow_mock:
            raise MLNodeError("Mock inputs require ML_NODE_ALLOW_MOCK=True")
        application = financial["application"]
        params = {"is_mock": "true" if financial.get("is_mock") else "false"}
        for key in ("application_id", "document_version"):
            if application.get(key) is not None:
                params[key] = str(application[key])
        if annual.get("period_end"):
            params["reporting_year"] = str(date.fromisoformat(annual["period_end"]).year)
        try:
            with httpx.Client(timeout=self.timeout, follow_redirects=False, trust_env=False) as client:
                response = client.post(self.url, json=annual["metrics"], params=params,
                                       headers={"X-API-Key": self.api_key})
            response.raise_for_status()
            result = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise MLNodeError("ML service unavailable or rejected financial input") from exc
        if result.get("schema_version") != 1 or result.get("model_outputs", {}).get("status") != "completed":
            raise MLNodeError("Unsupported ML response")
        for key in ("application_id", "document_version"):
            if str(result.get(key)) != str(application.get(key)):
                raise MLNodeError("ML result belongs to a different application/document version")
        if bool(result.get("is_mock")) != bool(financial.get("is_mock")):
            raise MLNodeError("ML response lost mock-data attribution")
        return result

    def build_bank_view(self, financial):
        """Return a new bank view + the complete audit response; never mutate node history."""
        prediction = self.predict_financial_analysis(financial)
        bank_view = copy.deepcopy(financial)
        bank_view["model_outputs"] = prediction["model_outputs"]
        bank_view["warnings"].extend({**warning, "fields": []} for warning in prediction["warnings"])
        return bank_view, prediction


def client_from_django_settings():
    from django.conf import settings
    return MLNodeClient(settings.ML_NODE_URL, settings.ML_NODE_API_KEY,
                        timeout=getattr(settings, "ML_NODE_TIMEOUT_SECONDS", 15.),
                        allow_mock=getattr(settings, "ML_NODE_ALLOW_MOCK", False))
