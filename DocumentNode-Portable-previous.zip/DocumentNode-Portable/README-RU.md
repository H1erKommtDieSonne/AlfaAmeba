# Переносимая нода документов

В этом комплекте нет AlfaAmeba. Включены API, обработчик документов, доставка callback, Redis, Ollama, mock-источник и сервис ML с обученными весами.

## Запуск

1. Установите Docker Desktop с Linux-контейнерами/WSL2 на Windows либо Docker Engine и Compose v2 на Linux.
2. Для NVIDIA установите драйвер. На Linux также нужен NVIDIA Container Toolkit. На Windows включите поддержку GPU в WSL2.
3. Windows: запустите `start.bat` (NVIDIA GPU) или `start.bat -Cpu` (CPU). Linux: `bash start.sh` (NVIDIA GPU) или `bash start.sh --cpu`.
4. Скрипт создаст `.env` с новыми ключами, соберёт образы, запустит сервисы и загрузит **единственную** модель `qwen3.5:35b-a3b`. Если модель уже есть в Docker-volume, повторного скачивания не будет.

Модель занимает около 22 ГБ на диске и **в архив не входит**. Интернет нужен для Docker-образов, Python-зависимостей и первоначальной загрузки модели. Это комплект для сборки, а не автономный офлайн-образ. Вес обычной ML-модели уже включён: `ml_node/models/credit_risk_suite_full.joblib`.

Контекст LLM: 32768 токенов. Таймаут запроса: 30 минут, загрузки модели: 15 минут, задачи: 3 часа. На сервере использовалась Tesla T4 15 ГБ с частичным размещением модели в RAM. Загрузка и скорость зависят от RAM/VRAM/swap другого ПК; CPU-режим значительно медленнее. Планируйте запас диска под Docker и 22 ГБ весов, не менее 40 ГБ свободного места для первого запуска.

## Подключение приложения

- API: `http://127.0.0.1:8000/docs`; заголовок `X-API-Key`, значение `API_KEY` из нового `.env`.
- Mock: `http://127.0.0.1:8010/health`; метрики: `/api/v1/organizations/{inn}/metrics?year=2025`.
- ML: `http://127.0.0.1:8020/ready`; ключ `ML_API_KEY`.
- В приложении задайте адрес API, новый API_KEY, адрес mock-источника и одинаковый callback-токен.
- Заполните `CALLBACK_URL`, `FEEDBACK_URL`, `CALLBACK_TOKEN` в `.env`. Если приложение работает на основном Windows ПК: `http://host.docker.internal:8080/api/v1/document-node/callback/` и `/api/v1/document-node/feedback/` соответственно. На Linux используйте доступный из Docker адрес приложения.
- Для подключения с другого компьютера измените `NODE_BIND_IP` на LAN-адрес ПК либо `0.0.0.0`, настройте firewall и перезапустите. По умолчанию порты доступны только локально.
- Старая внешняя сеть `alfa-node-net` не требуется; у комплекта собственная Docker-сеть. Ключи и адреса рабочего сервера не скопированы.

## Управление

Windows: `status.bat`, `stop.bat`. Linux: `docker compose ps`, `docker compose logs -f worker`, `docker compose stop`.

`stop` сохраняет модель, очередь и документы в Docker-volumes. Не используйте `down -v`, если хотите сохранить данные. Для остановки сервисов с GPU: `docker compose -f compose.yaml -f compose.gpu.yaml stop`.

Повторный запуск `start.bat`/`start.sh` сохраняет `.env` и данные. Для предварительно загруженной модели: `start.bat -SkipModelPull` или `bash start.sh --skip-model-pull` (скрипт проверит её наличие).

SHA256SUMS.json содержит контрольные суммы всех файлов исходного комплекта, кроме самого файла контрольных сумм и создаваемого позднее `.env`.
