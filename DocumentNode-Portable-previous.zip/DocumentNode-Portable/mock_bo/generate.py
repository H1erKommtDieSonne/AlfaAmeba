"""Generate deterministic, entirely synthetic fixtures. Never contacts FNS."""
import json
import random
from pathlib import Path


def demo_inn(index):
    base = f"9900{index:05d}"
    checksum = sum(int(n) * w for n, w in zip(base, [2, 4, 10, 3, 5, 9, 4, 6, 8])) % 11 % 10
    return base + str(checksum)


def generate(count=50):
    organizations = []
    for index in range(1, count + 1):
        reports = []
        for year in (2024, 2025):
            rng = random.Random(index * 10000 + year)
            assets = float(rng.randrange(12000, 300000))
            current = round(assets * rng.uniform(.35, .85), 2)
            equity = round(assets * rng.uniform(.2, .65), 2)
            if index % 11 == 0:
                equity = -round(assets * .12, 2)
            short = round((assets - equity) * rng.uniform(.5, .9), 2)
            cash = round(current * rng.uniform(.02, .18), 2)
            receivables = round(current * rng.uniform(.15, .5), 2)
            revenue = float(rng.randrange(20000, 500000))
            operating = round(revenue * rng.uniform(.02, .18), 2)
            net = round(operating * rng.uniform(.4, .85), 2)
            if index % 7 == 0:
                net, operating = -round(revenue * .04, 2), -round(revenue * .02, 2)
            if index == 1 and year == 2025:
                revenue, net, operating = 85000., 4200., 5100.
                assets, equity, current, short, cash, receivables = 60000., 22000., 45000., 35000., 3800., 19000.
            balance = {"1600": assets, "1300": equity, "1200": current,
                       "1500": short, "1250": cash, "1230": receivables,
                       "1100": round(assets - current, 2),
                       "1400": round(assets - equity - short, 2),
                       "1700": assets}
            income = {"2110": revenue, "2400": net, "2200": operating}
            scenario = "complete"
            if index % 10 == 0:
                income["2200"] = None
                scenario = "missing_operating_profit"
            elif index % 13 == 0:
                balance["1230"] = None
                scenario = "missing_receivables"
            reports.append({"year": year, "period_start": f"{year}-01-01",
                            "period_end": f"{year}-12-31", "as_of": f"{year}-12-31",
                            "currency": "RUB", "unit": "RUB_THOUSANDS",
                            "scenario": scenario, "balance": balance, "income_statement": income})
        organizations.append({"inn": demo_inn(index),
                              "name": f'ООО «Демо-организация {index:03d}»',
                              "applicant_type": "ooo",
                              "okved": ["47.11", "46.90", "62.01", "41.20", "10.71"][((index - 1) % 5)],
                              "is_mock": True, "reports": reports})
    return {"schema_version": 1, "is_mock": True,
            "description": "Синтетические организации и отчётность; не сведения ФНС.",
            "organizations": organizations}


if __name__ == "__main__":
    path = Path(__file__).parent / "data" / "organizations.json"
    path.write_text(json.dumps(generate(), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Generated 50 synthetic organizations: {path}")
