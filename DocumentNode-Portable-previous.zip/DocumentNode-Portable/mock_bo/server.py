"""Own demo API, not an implementation of the official FNS API protocol."""
import json
import re
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Query, Response

DATA = json.loads((Path(__file__).parent / "data" / "organizations.json").read_text(encoding="utf-8"))
ORGANIZATIONS = {org["inn"]: org for org in DATA["organizations"]}
SOURCES = {
    "revenue": ("income_statement", "2110"),
    "net_profit_current": ("income_statement", "2400"),
    "operating_profit_current": ("income_statement", "2200"),
    "total_assets": ("balance", "1600"), "equity": ("balance", "1300"),
    "current_assets": ("balance", "1200"),
    "short_term_liabilities": ("balance", "1500"),
    "cash": ("balance", "1250"), "receivables": ("balance", "1230"),
}
app = FastAPI(title="Mock БФО — синтетические данные", version="1.0.0",
              description="Отдельный демонстрационный API. Не официальный API ФНС. Все организации и суммы вымышлены.")


@app.middleware("http")
async def mark_mock(request, call_next):
    response = await call_next(request)
    response.headers["X-Data-Source"] = "mock-bo"
    response.headers["X-Mock-Data"] = "true"
    return response


def organization(inn):
    if not re.fullmatch(r"[0-9]{10}", inn):
        raise HTTPException(422, "Нужен 10-значный ИНН организации; сервис содержит только ООО")
    org = ORGANIZATIONS.get(inn)
    if org is None:
        raise HTTPException(404, "Организация отсутствует в демонстрационной базе")
    return org


def report_for(inn, year):
    org = organization(inn)
    if year is None:
        year = max(report["year"] for report in org["reports"])
    for report in org["reports"]:
        if report["year"] == year:
            return org, report
    raise HTTPException(404, "Отчётность за этот год отсутствует")


def company_card(org):
    return {key: value for key, value in org.items() if key != "reports"}


@app.get("/health")
async def health():
    return {"status": "ok", "is_mock": True, "organizations_count": len(ORGANIZATIONS)}


@app.get("/api/v1/organizations")
async def organizations(q: str = "", offset: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100)):
    found = [org for org in ORGANIZATIONS.values() if q.casefold() in org["name"].casefold() or q in org["inn"]]
    return {"is_mock": True, "total": len(found), "offset": offset, "limit": limit,
            "items": [company_card(org) for org in found[offset:offset + limit]]}


@app.get("/api/v1/organizations/{inn}")
async def get_organization(inn: str):
    org = organization(inn)
    return {**company_card(org), "reporting_years": sorted(report["year"] for report in org["reports"])}


@app.get("/api/v1/organizations/{inn}/reports/{year}")
async def get_report(inn: str, year: int):
    org, report = report_for(inn, year)
    return {"is_mock": True, "provider": "mock-bo", "schema_version": 1,
            "organization": company_card(org), "report": report}


@app.get("/api/v1/organizations/{inn}/metrics")
async def metrics(inn: str, year: int | None = None, unit: Literal["RUB_THOUSANDS", "RUB"] = "RUB_THOUSANDS"):
    org, report = report_for(inn, year)
    factor = 1000 if unit == "RUB" else 1
    values, provenance = {}, {}
    for field, (form, line) in SOURCES.items():
        raw = report[form].get(line)
        values[field] = round(raw * factor, 2) if raw is not None else None
        provenance[field] = {"provider": "mock-bo", "form": form, "line": line,
                             "method": "extracted" if raw is not None else "missing",
                             "raw_value": raw, "raw_unit": report["unit"],
                             "date": report["as_of"]}
    values["okved_group"] = org["okved"][:2]
    provenance["okved_group"] = {"provider": "mock-egrul", "method": "derived",
                                 "raw_value": org["okved"], "rule": "first_two_digits"}
    missing = [field for field, value in values.items() if value is None]
    return {"schema_version": 1, "is_mock": True, "provider": "mock-bo",
            "organization": company_card(org), "year": report["year"],
            "period_start": report["period_start"], "period_end": report["period_end"],
            "as_of": report["as_of"], "currency": "RUB", "unit": unit,
            "metrics": values, "provenance": provenance,
            "data_quality": {"complete": not missing, "missing_fields": missing,
                             "warnings": ["Синтетические демонстрационные данные"] +
                             (["Запросите расшифровку недостающих показателей"] if missing else [])}}


@app.get("/api/v1/organizations/{inn}/scoring-input")
async def scoring_input(inn: str, response: Response, year: int | None = None):
    result = await metrics(inn, year, "RUB_THOUSANDS")
    if not result["data_quality"]["complete"]:
        raise HTTPException(409, {"code": "missing_metrics", "is_mock": True,
                                  "missing_fields": result["data_quality"]["missing_fields"]})
    response.headers["X-Metrics-Unit"] = "RUB_THOUSANDS"
    return result["metrics"]


@app.get("/api/v1/document-requirements")
async def document_requirements(
    applicant_type: Literal["ooo", "ip"],
    loan_type: Literal["working_capital", "contract", "investment", "refinancing"] = "working_capital",
    tax_regime: Literal["usn_income", "usn_income_expense", "osno", "psn", "eshn", "other"] | None = None,
    has_collateral: bool = False,
):
    """Suggested application checklist, not a statement of statutory duties."""
    common = ["ИНН", "Тип заявителя", "Период доходов/расходов", "Дата остатков активов и долгов"]
    if applicant_type == "ooo":
        uploads = []
        external = ["Основной ОКВЭД", "Бухгалтерский баланс", "Отчёт о финансовых результатах"]
        conditional = ["Если отчётность не найдена: баланс и отчёт о финансовых результатах",
                       "Если строки отсутствуют/агрегированы: ОСВ или расшифровка нужных показателей"]
    else:
        if tax_regime is None:
            raise HTTPException(422, "Для ИП укажите tax_regime")
        common.append("Система налогообложения")
        accounting = {
            "usn_income": "Декларация УСН и КУДиР; фактические расходы — отдельно",
            "usn_income_expense": "Декларация УСН и КУДиР",
            "osno": "Декларация 3-НДФЛ и книга учёта доходов и расходов ИП",
            "psn": "Книга учёта доходов по патенту; декларация ПСН не запрашивается",
            "eshn": "Декларация ЕСХН и книга учёта доходов и расходов",
            "other": "Уточнить режим: документы доходов и расходов по применяемому режиму",
        }
        uploads = [accounting[tax_regime],
                   "Выписки по всем расчётным счетам за выбранный период (обычно 12 месяцев)",
                   "Управленческий отчёт: выручка, операционные расходы, проценты, налоги, прочие доходы/расходы",
                   "Анкета активов и обязательств на одну дату: деньги, запасы, дебиторка, имущество, кредиты, кредиторка, сроки долгов"]
        external = ["Основной ОКВЭД — из реестра ИП; в этом mock-bo реестр ИП не реализован"]
        conditional = ["Расшифровки и подтверждения активов/долгов, если анкеты недостаточно",
                       "Отчёты кассы/эквайринга, если часть продаж не видна в выписках"]
    if applicant_type == "ooo":
        uploads.append("Выписка по расчётному счёту — требование текущего кредитного продукта")
    product = {"working_capital": [], "contract": ["Контракт и предусмотренные им приложения"],
               "investment": ["Смета ИЛИ предложение поставщика"],
               "refinancing": ["Договоры рефинансируемых кредитов, графики и остатки долга"]}[loan_type]
    if has_collateral:
        product = product + ["Документы о праве собственности на залог"]
    return {"schema_version": 1, "is_mock": True, "policy": "demo_application_checklist",
            "applicant_type": applicant_type, "loan_type": loan_type,
            "request_fields": common, "initial_uploads": uploads,
            "external_fetch": external, "conditional_uploads": conditional,
            "product_uploads": product,
            "notes": ["Состав согласуется с требованиями банка; это не нормативный перечень",
                      "Налоговая прибыль и поступления на счёт не равны автоматически бухгалтерской прибыли и выручке",
                      "Недостающие значения остаются null; операционная прибыль не заменяется чистой",
                      "Для ИП расчётные показатели должны иметь источник и отметку об оценке",
                      "Количество пунктов не равно числу файлов: лимиты документной ноды остаются 5 файлов по 10 MiB"]}
