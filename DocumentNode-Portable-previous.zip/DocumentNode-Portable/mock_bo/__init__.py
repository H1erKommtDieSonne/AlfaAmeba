"""Standalone demonstration financial-reporting provider."""
