import ast
import importlib.util
import math
import unittest
from unittest.mock import patch
from pathlib import Path

import httpx
import numpy as np
import pandas as pd
from pydantic import ValidationError

from ml_node.main import create_app
from ml_node.schemas import CreditFeatures, ModelOutputs
from ml_node.scoring import recommendation

EXAMPLE = {"revenue": 85000., "net_profit_current": 4200., "operating_profit_current": 5100.,
           "total_assets": 60000., "equity": 22000., "current_assets": 45000.,
           "short_term_liabilities": 35000., "cash": 3800., "receivables": 19000., "okved_group": "47"}


class ContractTests(unittest.TestCase):
    def test_complete_input_and_validation(self):
        self.assertEqual(CreditFeatures(**EXAMPLE).okved_group, "47")
        for change in ({"revenue": None}, {"cash": -1.}, {"okved_group": 47}, {"revenue": True},
                       {"equity": float("nan")}, {"total_assets": 0.}, {"extra": 1}, {"current_assets": 999999.}):
            with self.assertRaises(ValidationError, msg=str(change)):
                CreditFeatures(**{**EXAMPLE, **change})
        self.assertEqual(CreditFeatures(**{**EXAMPLE, "equity": -1000., "net_profit_current": -10.}).equity, -1000.)

    def test_policy_threshold_boundaries(self):
        limit, result = recommendation(12000., 1., 40., 50.)
        self.assertEqual((limit, result["code"]), (200., "approved"))
        self.assertEqual(recommendation(12000., 1., 40.0001, 0.)[1]["reason"], "high_loss_probability")
        self.assertEqual(recommendation(12000., 1., 0., 50.0001)[1]["reason"], "high_liquidity_crisis_probability")
        self.assertEqual(recommendation(12000., .99, 0., 0.)[0], 100.)


class FakePredictor:
    info = {"version": "test-model"}
    def predict(self, features):
        return {"model_outputs": ModelOutputs(forecast_revenue_rub_thousands=12000., safe_credit_limit_rub_thousands=200.,
                    net_margin_percent=5., operating_margin_percent=8., loss_probability_percent=10.,
                    liquidity_crisis_probability_percent=5., decision="approved", note="test").model_dump(),
                "recommendation": {"code": "approved", "final_bank_decision": False}, "model": self.info,
                "feature_assumptions": [], "warnings": []}


class ApiTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        async def direct(function, *args, **kwargs):
            return function(*args, **kwargs)
        self.thread_patch = patch("ml_node.main.asyncio.to_thread", direct)
        self.thread_patch.start()
        self.app = create_app(FakePredictor(), api_key="test")
        self.lifespan = self.app.router.lifespan_context(self.app)
        await self.lifespan.__aenter__()
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=self.app), base_url="http://ml")

    async def asyncTearDown(self):
        await self.client.aclose()
        await self.lifespan.__aexit__(None, None, None)
        self.thread_patch.stop()

    async def test_predict_metadata_auth_and_types(self):
        self.assertEqual((await self.client.post("/v1/predict", json=EXAMPLE)).status_code, 401)
        result = await self.client.post("/v1/predict", json=EXAMPLE, headers={"X-API-Key": "test"},
            params={"application_id": "125", "document_version": 2, "reporting_year": 2025, "is_mock": "true"})
        self.assertEqual(result.status_code, 200, result.text)
        data = result.json()
        self.assertEqual((data["application_id"], data["document_version"], data["target_year"]), ("125", 2, 2026))
        self.assertIsInstance(data["model_outputs"]["forecast_revenue_rub_thousands"], float)
        self.assertIsNone(data["model_outputs"]["default_probability_percent"])
        self.assertEqual(data["warnings"][0]["severity"], "high")
        self.assertEqual((await self.client.get("/ready")).status_code, 200)

    async def test_missing_financial_field_returns_422(self):
        invalid = {key: value for key, value in EXAMPLE.items() if key != "cash"}
        response = await self.client.post("/v1/predict", json=invalid, headers={"X-API-Key": "test"})
        self.assertEqual(response.status_code, 422)


@unittest.skipUnless(importlib.util.find_spec("lightgbm"), "Run actual model tests in the ML Docker image")
class RealModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from ml_node.scoring import Predictor
        cls.predictor = Predictor()

    def test_matches_original_script_on_real_bundle(self):
        path = Path(__file__).resolve().parents[1] / "original/predict_application.py"
        tree = ast.parse(path.read_text())
        function = next(item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == "score_company_dict")
        namespace = {"np": np, "pd": pd, "prep": self.predictor.preprocessor, "mods": self.predictor.models}
        exec(compile(ast.Module(body=[function], type_ignores=[]), str(path), "exec"), namespace)
        for raw in (EXAMPLE, {**EXAMPLE, "net_profit_current": -1000., "equity": -2000.}):
            original = namespace["score_company_dict"](raw)
            result = self.predictor.predict(CreditFeatures(**raw))["model_outputs"]
            self.assertEqual(original["Прогноз выручки на год"], f'{result["forecast_revenue_rub_thousands"]:,.0f} тыс. руб.')
            self.assertEqual(original["Безопасный кредитный лимит"], f'{result["safe_credit_limit_rub_thousands"]:,.0f} тыс. руб.')
            self.assertEqual(original["Прогноз чистой маржи"], f'{result["net_margin_percent"]:+.2f}%')
            self.assertEqual(original["Прогноз операционной маржи"], f'{result["operating_margin_percent"]:+.2f}%')
            self.assertEqual(original["Вероятность чистого убытка"], f'{result["loss_probability_percent"]:.1f}%')
            self.assertEqual(original["Вероятность кассового разрыва (CR < 1)"], f'{result["liquidity_crisis_probability_percent"]:.1f}%')

    def test_results_finite_and_model_hash_known(self):
        result = self.predictor.predict(CreditFeatures(**EXAMPLE))
        self.assertEqual(result["model"]["artifact_sha256"], "f4be4fab28bcdcb0efc3c0c8f7c526473e8b8f3b88e7807b9e62eb57d868bd23")
        self.assertTrue(all(math.isfinite(value) for value in result["model_outputs"].values() if isinstance(value, float)))
        self.assertEqual(len(result["feature_assumptions"]), 3)


if __name__ == "__main__":
    unittest.main()
