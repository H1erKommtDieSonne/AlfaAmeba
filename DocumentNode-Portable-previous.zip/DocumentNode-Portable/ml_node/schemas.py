from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, StrictFloat, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class CreditFeatures(StrictModel):
    """All monetary input values are thousands of RUB, for one reporting period."""
    revenue: StrictFloat = Field(..., gt=0, le=1e15)
    net_profit_current: StrictFloat = Field(..., ge=-1e15, le=1e15)
    operating_profit_current: StrictFloat = Field(..., ge=-1e15, le=1e15)
    total_assets: StrictFloat = Field(..., gt=0, le=1e15)
    equity: StrictFloat = Field(..., ge=-1e15, le=1e15)
    current_assets: StrictFloat = Field(..., ge=0, le=1e15)
    short_term_liabilities: StrictFloat = Field(..., ge=0, le=1e15)
    cash: StrictFloat = Field(..., ge=0, le=1e15)
    receivables: StrictFloat = Field(..., ge=0, le=1e15)
    okved_group: str = Field(..., pattern=r"^[0-9]{2}$")
    gross_margin: StrictFloat | None = Field(None, ge=-1, le=1)
    revenue_growth_1y: StrictFloat | None = Field(None, ge=-1, le=1e6)
    loss_streak: int | None = Field(None, ge=0, le=100)

    @model_validator(mode="after")
    def assets_reconcile(self):
        if self.current_assets > self.total_assets + .01:
            raise ValueError("current_assets must not exceed total_assets")
        if self.cash + self.receivables > self.current_assets + .01:
            raise ValueError("cash + receivables must not exceed current_assets")
        return self


class ModelOutputs(StrictModel):
    # Same fields as the document node's financial_analysis.model_outputs.
    status: Literal["completed"] = "completed"
    forecast_revenue_rub_thousands: float
    safe_credit_limit_rub_thousands: float
    net_margin_percent: float
    operating_margin_percent: float
    loss_probability_percent: float = Field(..., ge=0, le=100)
    liquidity_crisis_probability_percent: float = Field(..., ge=0, le=100)
    default_probability_percent: None = None
    approval_probability_percent: None = None
    risk_grade: None = None
    decision: Literal["approved", "approved_with_discount", "rejected"]
    operating_cash_flow_forecast_rub: None = None
    note: str


class Warning(StrictModel):
    code: str
    severity: Literal["low", "medium", "high"]
    message: str


class PredictionResponse(StrictModel):
    schema_version: Literal[1] = 1
    application_id: str | None
    document_version: int | None
    reporting_year: int | None
    target_year: int | None
    is_mock: bool
    input_unit: Literal["RUB_THOUSANDS"] = "RUB_THOUSANDS"
    model_outputs: ModelOutputs
    recommendation: dict
    model: dict
    feature_assumptions: list[dict]
    warnings: list[Warning]
