"""Load only the locally packaged, hash-checked model. No upload endpoint."""
import hashlib
import io
import json
import warnings
import zlib
from pathlib import Path

from joblib.numpy_pickle import NumpyUnpickler
from sklearn import __version__ as sklearn_version
from sklearn.exceptions import InconsistentVersionWarning

from .preprocessing import FinancialPreprocessor

ROOT = Path(__file__).resolve().parent


class BundleUnpickler(NumpyUnpickler):
    def find_class(self, module, name):
        if module == "__main__" and name == "FinancialPreprocessor":
            return FinancialPreprocessor
        return super().find_class(module, name)


def load_bundle():
    manifest = json.loads((ROOT / "model-info.json").read_text())
    path = ROOT / "models" / manifest["artifact"]
    content = path.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    if digest != manifest["sha256"]:
        raise RuntimeError("Model artifact SHA-256 mismatch")
    if sklearn_version != manifest["sklearn_version"]:
        raise RuntimeError("scikit-learn runtime differs from the serialized model version")
    # The supplied artifact uses zlib; joblib's numpy-aware unpickler preserves arrays.
    with warnings.catch_warnings():
        warnings.simplefilter("error", InconsistentVersionWarning)
        unpickler = BundleUnpickler(str(path), io.BytesIO(zlib.decompress(content)), ensure_native_byte_order=True)
        bundle = unpickler.load()
    if not isinstance(bundle, dict) or not isinstance(bundle.get("preprocessor"), FinancialPreprocessor):
        raise RuntimeError("Unsupported bundle/preprocessor")
    if not isinstance(bundle.get("models"), dict) or set(bundle["models"]) != set(manifest["model_keys"]):
        raise RuntimeError("Model keys do not match manifest")
    return bundle, manifest
