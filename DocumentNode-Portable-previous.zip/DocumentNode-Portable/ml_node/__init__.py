"""Independent annual credit-scoring service."""
