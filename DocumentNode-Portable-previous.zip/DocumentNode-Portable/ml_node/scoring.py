"""Original feature engineering and recommendation policy, numeric JSON output."""
import math
import threading
from importlib.metadata import version
from time import perf_counter

import numpy as np
import pandas as pd

from .loader import load_bundle
from .schemas import CreditFeatures, ModelOutputs


def feature_frame(features: CreditFeatures):
    df = pd.DataFrame([features.model_dump()])
    rev, assets = features.revenue, features.total_assets
    debt, current, equity = features.short_term_liabilities, features.current_assets, features.equity
    df["current_ratio"] = current / debt if debt > 0 else np.nan
    df["cash_ratio"] = features.cash / debt if debt > 0 else np.nan
    df["receivables_to_revenue"] = features.receivables / rev
    # This is the original trained feature definition (short-term debt / assets).
    df["debt_to_assets"] = debt / assets
    df["equity_to_assets"] = equity / assets
    df["negative_equity"] = 1 if equity < 0 else 0
    for field in ("margin_current", "operating_margin", "gross_margin", "revenue_growth_1y", "loss_streak"):
        if field not in df:
            df[field] = np.nan
        else:
            df[field] = pd.to_numeric(df[field], errors="coerce")
    return df


def recommendation(revenue, net_margin_percent, loss_percent, liquidity_percent):
    limit = .20 * (revenue / 12)
    if loss_percent > 40.:
        code, reason, label = "rejected", "high_loss_probability", "ОТКАЗ: Высокая вероятность убытка"
    elif liquidity_percent > 50.:
        code, reason, label = "rejected", "high_liquidity_crisis_probability", "ОТКАЗ: Высокий риск дефицита ликвидности"
    elif net_margin_percent < 1.:
        code, reason, label = "approved_with_discount", "low_net_margin", "ОДОБРЕНО С ДИСКОНТОМ 50%: Низкая маржинальность"
        limit *= .5
    else:
        code, reason, label = "approved", "within_original_thresholds", "ОДОБРЕНО"
    return limit, {"code": code, "reason": reason, "label": label,
        "policy_version": "original-v1", "final_bank_decision": False,
        "limit_formula": "0.20 * forecast_annual_revenue / 12; x0.5 for low_net_margin",
        "thresholds": {"loss_probability_percent_gt": 40., "liquidity_crisis_probability_percent_gt": 50., "net_margin_percent_lt": 1.}}


class Predictor:
    def __init__(self, threads=1):
        self.threads = threads
        self.bundle, self.manifest = load_bundle()
        self.preprocessor, self.models = self.bundle["preprocessor"], self.bundle["models"]
        self.lock = threading.Lock()
        self.info = {"version": "credit-risk-" + self.manifest["sha256"][:12],
                     "artifact_sha256": self.manifest["sha256"], "model_keys": sorted(self.models),
                     "runtime": {name: version(name) for name in ("numpy", "pandas", "scikit-learn", "joblib", "lightgbm")}}
        # Readiness includes a real preprocessing + inference pass, not just file existence.
        self.predict(CreditFeatures(revenue=85000., net_profit_current=4200., operating_profit_current=5100.,
            total_assets=60000., equity=22000., current_assets=45000., short_term_liabilities=35000., cash=3800., receivables=19000., okved_group="47"))

    def predict(self, features):
        started = perf_counter()
        with self.lock:
            matrix = self.preprocessor.transform(feature_frame(features))
            values = {}
            for key in ("net_margin", "revenue", "operating_margin"):
                values[key] = float(self.models[key].predict(matrix, num_threads=self.threads)[0])
            for key in ("prob_loss", "prob_liquidity_crisis"):
                classes = list(self.models[key].classes_)
                if 1 not in classes:
                    raise RuntimeError("Classifier has no positive class")
                values[key] = float(self.models[key].predict_proba(matrix, num_threads=self.threads)[0, classes.index(1)])
        if not all(math.isfinite(value) for value in values.values()):
            raise RuntimeError("Model returned non-finite predictions")
        revenue = math.exp(values["revenue"])
        if not math.isfinite(revenue) or revenue <= 0 or not all(0 <= values[key] <= 1 for key in ("prob_loss", "prob_liquidity_crisis")):
            raise RuntimeError("Model predictions outside supported range")
        net_margin, op_margin = values["net_margin"] * 100, values["operating_margin"] * 100
        loss, liquidity = values["prob_loss"] * 100, values["prob_liquidity_crisis"] * 100
        limit, decision = recommendation(revenue, net_margin, loss, liquidity)
        outputs = ModelOutputs(forecast_revenue_rub_thousands=revenue, safe_credit_limit_rub_thousands=limit,
            net_margin_percent=net_margin, operating_margin_percent=op_margin,
            loss_probability_percent=loss, liquidity_crisis_probability_percent=liquidity,
            decision=decision["code"], note="Результаты пяти годовых моделей и правил исходного скрипта. Рекомендация не является окончательным решением банка; вероятности убытка и дефицита ликвидности не равны PD или вероятности одобрения.")
        assumptions = []
        for field, fallback in (("gross_margin", "training_median"), ("revenue_growth_1y", "zero_as_in_original_script"), ("loss_streak", "zero_as_in_original_script")):
            if getattr(features, field) is None:
                assumptions.append({"field": field, "method": fallback, "is_observed": False})
        effective_okved = features.okved_group if features.okved_group in self.preprocessor.top_okved_ else "99"
        if effective_okved != features.okved_group:
            assumptions.append({"field": "okved_group", "method": "unknown_category_to_99", "input": features.okved_group, "effective": "99"})
        warnings = [{"code": "default_features_applied", "severity": "medium", "message": "Для части дополнительных признаков применены значения исходного препроцессора; они не подтверждены документами."}] if assumptions else []
        return {"model_outputs": outputs.model_dump(), "recommendation": decision,
                "model": {**self.info, "duration_ms": round((perf_counter() - started) * 1000, 3), "effective_okved_group": effective_okved},
                "feature_assumptions": assumptions, "warnings": warnings}
