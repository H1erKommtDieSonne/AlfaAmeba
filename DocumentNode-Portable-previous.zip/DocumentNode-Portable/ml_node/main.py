import logging
import asyncio
import os
import secrets
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Query

from .schemas import CreditFeatures, PredictionResponse


def create_app(predictor=None, api_key=None):
    key = os.getenv("ML_API_KEY", "") if api_key is None else api_key

    @asynccontextmanager
    async def lifespan(app):
        if not key:
            raise RuntimeError("ML_API_KEY is required")
        if predictor is None:
            from .scoring import Predictor
            threads = int(os.getenv("ML_NUM_THREADS", "1"))
            if not 1 <= threads <= 32:
                raise RuntimeError("ML_NUM_THREADS must be between 1 and 32")
            app.state.predictor = Predictor(threads)
        else:
            app.state.predictor = predictor
        yield

    app = FastAPI(title="Credit ML Node", version="1.0.0", lifespan=lifespan,
                  description="Пять годовых моделей. Денежные входы и выходы — тысячи рублей. Результат совместим с financial_analysis.model_outputs документной ноды.")

    def authorize(value):
        if not key or not value or not secrets.compare_digest(value, key):
            raise HTTPException(401, "Invalid X-API-Key")

    @app.get("/health")
    async def health():
        return {"status": "ok", "service": "credit-ml"}

    @app.get("/ready")
    async def ready():
        if not getattr(app.state, "predictor", None):
            raise HTTPException(503, "Model not ready")
        return {"status": "ok", "model_version": app.state.predictor.info["version"]}

    @app.get("/v1/model")
    async def model(x_api_key: str | None = Header(None)):
        authorize(x_api_key)
        return app.state.predictor.info

    @app.post("/v1/predict", response_model=PredictionResponse, summary="Годовой прогноз по финансовым показателям")
    async def predict(
        body: CreditFeatures,
        application_id: str | None = Query(None, max_length=120),
        document_version: int | None = Query(None, ge=1),
        reporting_year: int | None = Query(None, ge=2000, le=2100),
        is_mock: bool = False,
        x_api_key: str | None = Header(None),
    ):
        authorize(x_api_key)
        backend = getattr(app.state, "predictor", None)
        if backend is None:
            raise HTTPException(503, "Model not ready")
        try:
            result = await asyncio.to_thread(backend.predict, body)
        except Exception:
            logging.exception("Credit prediction failed")
            raise HTTPException(503, "Prediction failed; retry later")
        if is_mock:
            result["warnings"].append({"code": "mock_data", "severity": "high", "message": "Входные данные демонстрационные; результат не является оценкой реального клиента."})
        return {"schema_version": 1, "application_id": application_id, "document_version": document_version,
                "reporting_year": reporting_year, "target_year": reporting_year + 1 if reporting_year else None,
                "is_mock": is_mock, "input_unit": "RUB_THOUSANDS", **result}

    return app


app = create_app()
