"""Unchanged feature transformation from the supplied training-side script."""
import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler
from sklearn.impute import SimpleImputer

class FinancialPreprocessor:
    def __init__(self):
        self.num_cols = [
            'margin_current', 'operating_margin', 'gross_margin', 'operating_gap',
            'revenue', 'net_profit_current', 'operating_profit_current', 'total_assets', 'equity',
            'asset_turnover', 'current_ratio', 'cash_ratio', 'receivables_to_revenue', 'working_capital_to_assets',
            'debt_to_assets', 'equity_to_assets', 'negative_equity',
            'revenue_growth_1y', 'loss_streak'
        ]
        self.imputer = SimpleImputer(strategy='median', add_indicator=True)
        self.scaler = RobustScaler()
        self.top_okved_ = []
        self.imputer_feature_names_ = []

    def _engineer_features(self, data):
        df_out = data.copy()
        df_out.replace([np.inf, -np.inf], np.nan, inplace=True)
        
        df_out['asset_turnover'] = (df_out['revenue'] / df_out['total_assets']).replace([np.inf, -np.inf], np.nan)
        calc_margin = (df_out['net_profit_current'] / df_out['revenue']).replace([np.inf, -np.inf], np.nan)
        df_out['margin_current'] = df_out['margin_current'].fillna(calc_margin)
        
        calc_op = (df_out['operating_profit_current'] / df_out['revenue']).replace([np.inf, -np.inf], np.nan)
        df_out['operating_margin'] = df_out['operating_margin'].fillna(calc_op).fillna(df_out['margin_current'])
        df_out['operating_gap'] = df_out['margin_current'] - df_out['operating_margin']
        
        working_cap = df_out['current_assets'].fillna(0) - df_out['short_term_liabilities'].fillna(0)
        df_out['working_capital_to_assets'] = (working_cap / df_out['total_assets']).replace([np.inf, -np.inf], np.nan)
        
        for col in ['margin_current', 'operating_margin', 'gross_margin', 'operating_gap']:
            if col in df_out.columns:
                df_out[col] = df_out[col].clip(-1.0, 1.0)
                
        for col in ['revenue_growth_1y', 'loss_streak']:
            if col in df_out.columns:
                df_out[col] = df_out[col].fillna(0.0)
                
        if 'okved_group' in df_out.columns:
            df_out['okved_group'] = df_out['okved_group'].astype(str).str.strip().str[:2]
            df_out['okved_group'] = df_out['okved_group'].replace({'na': '99', 'nan': '99', 'No': '99', '': '99', 'None': '99'}).fillna('99')
            
        return df_out

    def transform(self, X):
        df_proc = self._engineer_features(X)
        if 'okved_group' in df_proc.columns:
            df_proc.loc[~df_proc['okved_group'].isin(self.top_okved_), 'okved_group'] = '99'
            okved_cat = df_proc['okved_group'].astype('category').values
        else:
            okved_cat = np.array(['99'] * len(df_proc), dtype='category')
            
        X_num = df_proc[self.num_cols]
        X_imp = self.imputer.transform(X_num)
        X_log = np.sign(X_imp) * np.log1p(np.abs(X_imp))
        X_scaled = self.scaler.transform(X_log)
        
        X_out = pd.DataFrame(X_scaled, columns=self.imputer_feature_names_)
        X_out['okved_group'] = okved_cat
        return X_out
