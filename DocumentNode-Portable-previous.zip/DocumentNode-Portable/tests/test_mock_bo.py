import json
import unittest

import httpx

from mock_bo.generate import demo_inn, generate
from mock_bo.server import DATA, SOURCES, app


class FixtureTests(unittest.TestCase):
    def test_fixtures_are_reproducible_and_consistent(self):
        self.assertEqual(DATA, generate())
        self.assertEqual(len(DATA["organizations"]), 50)
        self.assertEqual(len({org["inn"] for org in DATA["organizations"]}), 50)
        for org in DATA["organizations"]:
            self.assertTrue(org["is_mock"])
            checksum = sum(int(n) * w for n, w in zip(org["inn"][:9], [2, 4, 10, 3, 5, 9, 4, 6, 8])) % 11 % 10
            self.assertEqual(int(org["inn"][-1]), checksum)
            for report in org["reports"]:
                balance = report["balance"]
                self.assertAlmostEqual(balance["1600"], balance["1300"] + balance["1400"] + balance["1500"], places=2)
                self.assertAlmostEqual(balance["1600"], balance["1100"] + balance["1200"], places=2)
                self.assertLessEqual(balance["1250"] + (balance["1230"] or 0), balance["1200"])
        json.dumps(DATA, allow_nan=False)


class MockAPITests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://mock")

    async def asyncTearDown(self):
        await self.client.aclose()

    async def test_metrics_match_requested_example_and_normalize_units(self):
        path = f"/api/v1/organizations/{demo_inn(1)}/metrics"
        response = await self.client.get(path)
        result = response.json()
        self.assertEqual(response.headers["X-Mock-Data"], "true")
        self.assertEqual(result["year"], 2025)
        self.assertEqual(result["metrics"], {
            "revenue": 85000., "net_profit_current": 4200., "operating_profit_current": 5100.,
            "total_assets": 60000., "equity": 22000., "current_assets": 45000.,
            "short_term_liabilities": 35000., "cash": 3800., "receivables": 19000., "okved_group": "47"})
        rubles = (await self.client.get(path, params={"unit": "RUB"})).json()
        self.assertEqual(rubles["metrics"]["revenue"], 85000000.)
        self.assertEqual(rubles["provenance"]["revenue"]["raw_value"], 85000.)
        self.assertEqual(set(result["provenance"]), set(SOURCES) | {"okved_group"})

    async def test_missing_metrics_are_not_substituted(self):
        prefix = f"/api/v1/organizations/{demo_inn(10)}"
        result = (await self.client.get(prefix + "/metrics")).json()
        self.assertIsNone(result["metrics"]["operating_profit_current"])
        self.assertIsNotNone(result["metrics"]["net_profit_current"])
        self.assertEqual(result["data_quality"]["missing_fields"], ["operating_profit_current"])
        self.assertEqual((await self.client.get(prefix + "/scoring-input")).status_code, 409)
        ready = await self.client.get(f"/api/v1/organizations/{demo_inn(1)}/scoring-input")
        self.assertEqual(ready.status_code, 200)
        self.assertEqual(len(ready.json()), 10)
        self.assertEqual(ready.headers["X-Metrics-Unit"], "RUB_THOUSANDS")

    async def test_search_history_and_unknown_organizations(self):
        result = (await self.client.get("/api/v1/organizations", params={"offset": 40, "limit": 20})).json()
        self.assertEqual(result["total"], 50)
        self.assertEqual(len(result["items"]), 10)
        found = (await self.client.get("/api/v1/organizations", params={"q": demo_inn(1)})).json()
        self.assertEqual(found["total"], 1)
        prefix = f"/api/v1/organizations/{demo_inn(1)}"
        self.assertEqual((await self.client.get(prefix + "/reports/2024")).status_code, 200)
        self.assertEqual((await self.client.get(prefix + "/reports/2026")).status_code, 404)
        self.assertEqual((await self.client.get("/api/v1/organizations/7700000000")).status_code, 404)
        self.assertEqual((await self.client.get("/api/v1/organizations/invalid")).status_code, 422)

    async def test_checklist_depends_on_applicant_and_product(self):
        path = "/api/v1/document-requirements"
        ooo = (await self.client.get(path, params={"applicant_type": "ooo"})).json()
        self.assertEqual(len(ooo["initial_uploads"]), 1)
        self.assertTrue(ooo["external_fetch"])
        ip = (await self.client.get(path, params={"applicant_type": "ip", "tax_regime": "psn",
                                               "loan_type": "contract", "has_collateral": "true"})).json()
        self.assertIn("декларация ПСН не запрашивается", ip["initial_uploads"][0])
        self.assertEqual(len(ip["product_uploads"]), 2)
        self.assertEqual((await self.client.get(path, params={"applicant_type": "ip"})).status_code, 422)


if __name__ == "__main__":
    unittest.main()
