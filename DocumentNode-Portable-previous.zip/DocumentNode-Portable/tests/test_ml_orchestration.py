import copy
import json
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
import httpx
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'api'))
from ml_client import enrich_with_models
from finance_schema import AnalystResult
ROOT = Path(__file__).resolve().parents[1]

class OrchestrationTests(unittest.TestCase):
    def test_ready_success_and_failed_response(self):
        financial = json.loads((ROOT/'examples/financial-v2/financial-result.json').read_text())
        response = json.loads((ROOT/'examples/ml/response.json').read_text())
        for k in ('application_id', 'document_version'):
            response[k] = financial['application'].get(k)
        response['is_mock'] = bool(financial['is_mock'])
        real_client = httpx.Client
        calls = []
        def handler(request):
            calls.append(request)
            return httpx.Response(200,json=response)
        def client(**kwargs):
            return real_client(transport=httpx.MockTransport(handler),**kwargs)
        with patch.dict(os.environ, {'ML_NODE_URL':'http://ml', 'ML_NODE_API_KEY':'test'}), patch('ml_client.httpx.Client',client):
            result = copy.deepcopy(financial)
            enrich_with_models(result)
            self.assertEqual(result['model_outputs']['status'],'completed')
            AnalystResult.model_validate(result)
            self.assertEqual(len(calls),1)
            result = copy.deepcopy(financial)
            result['annual_model_input']['missing_fields']=['cash']
            enrich_with_models(result)
            self.assertEqual(len(calls),1)
            response['document_version'] = 999999
            result = copy.deepcopy(financial)
            enrich_with_models(result)
            self.assertEqual(result['model_outputs']['status'],'failed')
            self.assertEqual(result['warnings'][-1]['severity'],'high')
            self.assertEqual(result['statistics'],financial['statistics'])
            AnalystResult.model_validate(result)

    def test_unavailable_preserves_document_results(self):
        result=json.loads((ROOT/'examples/financial-v2/financial-result.json').read_text())
        with patch.dict(os.environ,{'ML_NODE_URL':'http://ml'}), patch('ml_client.httpx.Client',side_effect=httpx.ConnectError('offline')):
            enrich_with_models(result)
        self.assertEqual(result['model_outputs']['status'],'failed')
        self.assertIsNone(result['model_outputs']['decision'])
