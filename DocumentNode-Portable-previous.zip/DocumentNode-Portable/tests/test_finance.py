import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import httpx
from pydantic import ValidationError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "api"))
from finance import money, prepare_financial_analysis
from finance_schema import ApplicationContext, ExtractionResponse, FinancialData, Observation
from bank_csv import parse_bank_csv
import analysis_pipeline
import main

HEADER = "transaction_id,account_id,date,direction,amount,currency,category,counterparty_id\n"
CSV = HEADER + "\n".join([
    "1,A,2026-01-10,in,100,RUB,customer_receipt,buyer",
    "2,A,2026-01-11,in,1000,RUB,loan_received,bank",
    "3,A,2026-01-12,in,500,RUB,internal_transfer,own",
    "4,A,2026-01-13,out,50,RUB,operating_payment,supplier",
    "5,A,2026-01-14,out,20,RUB,debt_principal,bank",
    "6,A,2026-01-15,out,500,RUB,internal_transfer,own",
    "7,A,2026-02-10,in,200,RUB,customer_receipt,buyer",
    "8,A,2026-02-11,out,80,RUB,operating_payment,supplier",
    "9,A,2026-02-12,out,20,RUB,debt_principal,bank",
    "10,A,2026-03-10,in,300,RUB,customer_receipt,buyer",
    "11,A,2026-03-11,out,100,RUB,operating_payment,supplier",
    "12,A,2026-03-12,out,20,RUB,debt_principal,bank",
]) + "\n"


def report():
    return {"provider": "mock-bo", "is_mock": True, "organization": {"inn": "9900000017"},
            "currency": "RUB", "unit": "RUB_THOUSANDS", "period_start": "2025-01-01",
            "period_end": "2025-12-31", "as_of": "2025-12-31",
            "metrics": {"revenue": 85000., "net_profit_current": 4200., "operating_profit_current": 5100.,
                        "total_assets": 60000., "equity": 22000., "current_assets": 45000.,
                        "short_term_liabilities": 35000., "cash": 3800., "receivables": 19000., "okved_group": "47"}}


def context():
    return {"application_id": "125", "document_version": 2, "borrower_inn": "9900000017",
            "loan_type": "working_capital", "reporting_year": 2025, "analysis_date": "2026-04-01",
            "forecast_month": "2026-04",
            "expected_account_ids": ["A"], "provider_reports": [report()],
            "statement_periods": [{"filename": "bank.csv", "account_id": "A", "period_start": "2026-01-01",
                                   "period_end": "2026-03-31", "opening_balance_rub": 1000.,
                                   "closing_balance_rub": 2310., "complete": True}],
            "debt_schedule_complete": True, "debt_schedule_start": "2026-04-01", "debt_schedule_end": "2026-04-30",
            "proposed_monthly_payment_rub": 20.,
            "financial_data": {"debt_payments": [{"loan_id": "existing", "due_date": "2026-04-15",
                "principal": 8., "interest": 2., "fees": 0., "unit": "RUB", "source": {"provider": "test", "locator": "payment 1"}}]}}


class FinanceTests(unittest.TestCase):
    def test_warning_severity_is_explicit_and_deterministic(self):
        import ast
        import inspect
        import finance
        codes = {node.args[0].value for node in ast.walk(ast.parse(inspect.getsource(finance)))
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "warn"
                 and node.args and isinstance(node.args[0], ast.Constant)}
        self.assertEqual(codes, set(finance.WARNING_SEVERITIES))
        ctx = context()
        other = copy.deepcopy(ctx["provider_reports"][0])
        other["metrics"]["revenue"] += 100.
        ctx["provider_reports"].append(other)
        warnings = prepare_financial_analysis(ctx)["warnings"]
        levels = {item["code"]: item["severity"] for item in warnings}
        self.assertEqual(levels["conflicting_metrics"], "high")
        self.assertEqual(levels["seasonality_not_estimated"], "low")
        self.assertEqual(levels["mock_data"], "high")
        self.assertTrue(all(item["severity"] in {"low", "medium", "high"} for item in warnings))
        ctx = context()
        ctx["analysis_date"] = "2026-10-24"
        stale = prepare_financial_analysis(ctx, self.data(ctx))["warnings"]
        self.assertEqual(next(item["severity"] for item in stale if item["code"] == "stale_bank_history"), "medium")

    def data(self, ctx=None, text=CSV):
        return parse_bank_csv("bank.csv", text.encode(), ctx or context())

    def test_annual_input_and_no_fake_model_outputs(self):
        result = prepare_financial_analysis(context())
        self.assertTrue(result["annual_model_input"]["ready"])
        self.assertEqual(result["annual_model_input"]["metrics"], report()["metrics"])
        self.assertTrue(result["is_mock"])
        self.assertIsNone(result["model_outputs"]["default_probability_percent"])
        self.assertIsNone(result["model_outputs"]["decision"])
        self.assertEqual(money(123456.78, "RUB", "RUB_THOUSANDS"), 123.45678)

    def test_transactions_classified_and_forecast_debt_not_double_counted(self):
        data = self.data()
        self.assertEqual(data.cash_flow_months[0].inflows, 1600.)
        self.assertEqual(data.cash_flow_months[0].customer_receipts, 100.)
        self.assertEqual(data.cash_flow_months[0].operating_payments, 50.)
        self.assertEqual(data.cash_flow_months[0].debt_service, 20.)
        result = prepare_financial_analysis(context(), data)
        self.assertTrue(result["readiness"]["balance_after_all_debt"])
        base = result["next_month_forecast"]["scenarios"][0]
        self.assertEqual(base["customer_receipts_rub"], 200.)
        self.assertEqual(base["operating_payments_rub"], 76.67)
        self.assertEqual(base["existing_debt_service_rub"], 10.)
        self.assertEqual(base["balance_after_all_debt_rub"], 2403.33)
        self.assertEqual(result["statistics"]["largest_customer_receipts_share"]["value"], 1.)
        self.assertIsNone(result["next_month_forecast"]["cash_gap_probability"])
        self.assertIsNone(result["next_month_forecast"]["backtest"]["mae_rub"])

    def test_partial_month_missing_account_and_stale_history_block_forecast(self):
        for mutation in ("partial", "missing_account", "stale", "unreconciled"):
            ctx = context()
            if mutation == "partial":
                ctx["statement_periods"][0]["period_start"] = "2026-01-02"
            if mutation == "missing_account":
                ctx["expected_account_ids"].append("B")
            if mutation == "stale":
                ctx["analysis_date"] = "2026-10-24"
            if mutation == "unreconciled":
                ctx["statement_periods"][0]["closing_balance_rub"] = 9999.
            result = prepare_financial_analysis(ctx, self.data(ctx))
            self.assertFalse(result["readiness"]["next_month_receipts_and_operating_payments"], mutation)
            self.assertEqual(result["next_month_forecast"]["scenarios"], [], mutation)

    def test_unknown_debt_and_proposed_payment_are_null_not_zero(self):
        ctx = context()
        del ctx["proposed_monthly_payment_rub"]
        ctx["debt_schedule_complete"] = False
        result = prepare_financial_analysis(ctx, self.data(ctx))
        self.assertTrue(result["next_month_forecast"]["ready"])
        base = result["next_month_forecast"]["scenarios"][0]
        self.assertIsNone(base["existing_debt_service_rub"])
        self.assertIsNone(base["balance_after_all_debt_rub"])
        self.assertIsNone(base["cash_gap_rub"])
        self.assertFalse(result["readiness"]["balance_after_all_debt"])

    def test_duplicates_do_not_double_amounts_and_conflicts_are_blocked(self):
        doubled = CSV + CSV.splitlines()[1] + "\n"
        self.assertEqual(self.data(text=doubled).cash_flow_months[0].inflows, 1600.)
        result = prepare_financial_analysis(context(), FinancialData(cash_flow_months=self.data().cash_flow_months * 2))
        self.assertEqual(result["cash_flow"]["months"][0]["inflows"], 1600.)
        with self.assertRaises(ValueError):
            self.data(text=doubled.replace("1,A,2026-01-10,in,100,RUB", "1,A,2026-01-10,in,999,RUB", 1))

    def test_missing_and_conflicting_annual_data_do_not_get_imputed(self):
        ctx = context()
        ctx["provider_reports"][0]["metrics"]["operating_profit_current"] = None
        result = prepare_financial_analysis(ctx)
        self.assertIsNone(result["annual_model_input"]["metrics"]["operating_profit_current"])
        self.assertFalse(result["annual_model_input"]["ready"])
        self.assertIsNone(result["statistics"]["debt_to_ebitda"]["value"])
        ctx = context()
        other = copy.deepcopy(ctx["provider_reports"][0])
        other["metrics"]["revenue"] += 100.
        ctx["provider_reports"].append(other)
        result = prepare_financial_analysis(ctx)
        self.assertIsNone(result["annual_model_input"]["metrics"]["revenue"])
        self.assertIn("conflicting_metrics", [w["code"] for w in result["warnings"]])

    def test_period_mismatch_and_wrong_subject_are_not_merged(self):
        ctx = context()
        ctx["provider_reports"][0]["as_of"] = "2024-12-31"
        result = prepare_financial_analysis(ctx)
        self.assertIsNone(result["annual_model_input"]["metrics"]["total_assets"])
        ctx = context()
        ctx["borrower_inn"] = "7700000000"
        result = prepare_financial_analysis(ctx)
        self.assertFalse(result["annual_model_input"]["ready"])
        self.assertTrue(all(value is None for value in result["annual_model_input"]["metrics"].values()))

    def test_dscr_and_ebitda_require_sourced_matched_inputs(self):
        ctx = context()
        ctx["debt_schedule_start"] = "2025-01-01"
        ctx["financial_data"]["debt_payments"].append({"loan_id": "old", "due_date": "2025-06-01", "principal": 100., "interest": 10., "fees": 0., "unit": "RUB", "source": {"provider": "test", "locator": "old payment"}})
        facts = [
            {"field": "ebitda", "value": 500., "unit": "RUB", "period_start": "2025-01-01", "period_end": "2025-12-31"},
            {"field": "total_debt", "value": 1000., "unit": "RUB", "as_of": "2025-12-31"},
            {"field": "cfads", "value": 220., "unit": "RUB", "period_start": "2025-01-01", "period_end": "2025-12-31"},
        ]
        ctx["financial_data"]["supplemental_metrics"] = [{**fact, "source": {"provider": "test", "locator": fact["field"]}} for fact in facts]
        result = prepare_financial_analysis(ctx)
        self.assertEqual(result["statistics"]["dscr"]["value"], 2.)
        self.assertEqual(result["statistics"]["debt_to_ebitda"]["value"], 2.)
        self.assertTrue(result["readiness"]["dscr"])

    def test_booleans_nonfinite_and_unknown_units_rejected(self):
        for value in (True, float("inf"), float("nan"), "85000"):
            with self.assertRaises(ValidationError):
                Observation(field="revenue", value=value, unit="RUB", source={"provider": "test", "locator": "x"})
        ctx = context()
        ctx["provider_reports"][0]["unit"] = "USD"
        with self.assertRaises(ValidationError):
            ApplicationContext.model_validate(ctx)

    def test_empty_zero_months_are_preserved_with_confirmed_coverage(self):
        ctx = context()
        ctx["statement_periods"][0]["closing_balance_rub"] = 1000.
        parsed = self.data(ctx, HEADER)
        self.assertEqual(len(parsed.cash_flow_months), 3)
        result = prepare_financial_analysis(ctx, parsed)
        self.assertEqual(result["cash_flow"]["complete_months"], 3)
        self.assertEqual(result["cash_flow"]["months"][0]["inflows"], 0.)

    def test_default_next_calendar_month_includes_intermediate_cash_bridge(self):
        ctx = context()
        del ctx["forecast_month"]
        ctx["debt_schedule_end"] = "2026-05-31"
        ctx["financial_data"]["debt_payments"].append({"loan_id": "existing", "due_date": "2026-05-15", "principal": 8., "interest": 2., "fees": 0., "unit": "RUB", "source": {"provider": "test", "locator": "payment 2"}})
        result = prepare_financial_analysis(ctx, self.data(ctx))
        forecast = result["next_month_forecast"]
        self.assertEqual(forecast["period"], "2026-05")
        self.assertEqual(forecast["horizon_months_after_last_observation"], 2)
        base = forecast["scenarios"][0]
        self.assertEqual([row["month"] for row in base["projection_path"]], ["2026-04", "2026-05"])
        self.assertEqual(base["opening_balance_rub"], 2423.33)
        self.assertEqual(base["balance_after_all_debt_rub"], 2516.66)
        self.assertEqual(base["projection_path"][0]["proposed_credit_payment_rub"], 0.)

    def test_missing_fees_are_not_silently_zero_and_total_payment_can_be_used(self):
        ctx = context()
        payment = ctx["financial_data"]["debt_payments"][0]
        del payment["fees"]
        result = prepare_financial_analysis(ctx, self.data(ctx))
        self.assertFalse(result["readiness"]["balance_after_all_debt"])
        payment["total_payment"] = 10.
        result = prepare_financial_analysis(ctx, self.data(ctx))
        self.assertTrue(result["readiness"]["balance_after_all_debt"])


class PipelineTests(unittest.TestCase):
    def test_model_schema_binds_filename_and_node_restores_omitted_identity(self):
        response_data = {"financial_data": {"annual_metrics": [{"field": "revenue", "value": 123., "unit": "RUB_THOUSANDS",
                         "period_start": "2025-01-01", "period_end": "2025-12-31",
                         "source": {"locator": "line 1", "quote": "revenue 123"}}]}}
        requests = []
        def handler(request):
            requests.append(json.loads(request.content))
            return httpx.Response(200, json={"done_reason": "stop", "message": {"content": json.dumps(response_data)}})
        real_client = httpx.Client
        def client(**kwargs):
            return real_client(transport=httpx.MockTransport(handler), **kwargs)
        with patch.object(analysis_pipeline.httpx, "Client", client):
            result = analysis_pipeline._call_model("known.txt", "revenue 123", ApplicationContext(), "", "http://unused")
        self.assertEqual(result.financial_data.annual_metrics[0].source.filename, "known.txt")
        schema = requests[0]["format"]["$defs"]["Source"]
        self.assertEqual(schema["properties"]["filename"]["const"], "known.txt")
        self.assertIn("filename", schema["required"])

    def test_canonical_csv_works_without_llm(self):
        with patch.object(analysis_pipeline, "_call_model", side_effect=AssertionError("LLM should not be called")):
            result = analysis_pipeline.analyze_files([("bank.csv", CSV.encode())], "", context(), "http://unused")
        self.assertEqual(result["result"]["schema_version"], 2)
        self.assertTrue(result["result"]["financial_analysis"]["readiness"]["annual_model"])
        self.assertEqual(result["files"][0]["method"], "structured_csv")

    def test_fabricated_quote_is_excluded(self):
        observation = {"field": "revenue", "value": 123., "unit": "RUB_THOUSANDS",
                       "period_start": "2025-01-01", "period_end": "2025-12-31",
                       "source": {"filename": "a.txt", "locator": "line 1", "quote": "invented evidence"}}
        extracted = ExtractionResponse(financial_data={"annual_metrics": [observation]})
        with patch.object(analysis_pipeline, "_call_model", return_value=extracted):
            result = analysis_pipeline.analyze_files([("a.txt", b"actual text")], "", {"loan_type": "working_capital", "analysis_date": "2026-04-01"}, "http://unused")
        self.assertIsNone(result["result"]["financial_analysis"]["annual_model_input"]["metrics"]["revenue"])
        self.assertIn("uncertain_recognition", [issue["code"] for issue in result["result"]["issues"]])

    def test_truncated_file_does_not_supply_model_inputs(self):
        extracted = ExtractionResponse(financial_data={"annual_metrics": [{
            "field": "revenue", "value": 123., "unit": "RUB_THOUSANDS", "period_start": "2025-01-01", "period_end": "2025-12-31",
            "source": {"filename": "a.txt", "locator": "line 1", "quote": "actual"}}]})
        with patch.object(analysis_pipeline, "_call_model", return_value=extracted), patch.object(analysis_pipeline, "CHUNK_SIZE", 10), patch.object(analysis_pipeline, "MAX_CHUNKS", 1):
            result = analysis_pipeline.analyze_files([("a.txt", b"actual evidence and a lot more text")], "", {"loan_type": "working_capital", "analysis_date": "2026-04-01"}, "http://unused")
        self.assertTrue(result["files"][0]["truncated"])
        self.assertEqual(result["result"]["status"], "needs_review")
        self.assertIsNone(result["result"]["financial_analysis"]["annual_model_input"]["metrics"]["revenue"])


class FinancialAPITests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.key = patch.object(main, "API_KEY", "test")
        self.key.start()
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=main.app), base_url="http://node")

    async def asyncTearDown(self):
        await self.client.aclose()
        self.key.stop()

    async def test_prepare_auth_schema_and_validation(self):
        self.assertEqual((await self.client.post("/financial/prepare", json={"application_context": {}})).status_code, 401)
        headers = {"X-API-Key": "test"}
        response = await self.client.post("/financial/prepare", headers=headers, json={"application_context": context(), "financial_data": parse_bank_csv("bank.csv", CSV.encode(), context()).model_dump(mode="json")})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertTrue(response.json()["readiness"]["annual_model"])
        schema = await self.client.get("/financial/schema", headers=headers)
        self.assertEqual(schema.status_code, 200)
        self.assertIn("AnnualInput", schema.json()["analyst_result"]["$defs"])
        bad = context()
        bad["provider_reports"][0]["metrics"]["revenue"] = "not numeric"
        self.assertEqual((await self.client.post("/financial/prepare", headers=headers, json={"application_context": bad})).status_code, 422)

    async def test_jobs_persists_typed_context_without_live_redis(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(main, "JOBS_DIR", Path(tmp)), patch.object(main.Redis, "from_url", return_value=Mock()), patch.object(main, "Queue", return_value=Mock()) as queue:
            response = await self.client.post("/jobs", headers={"X-API-Key": "test"}, data={"application_context": json.dumps(context())}, files=[("files", ("bank.csv", CSV, "text/csv"))])
            self.assertEqual(response.status_code, 202, response.text)
            manifest = json.loads((Path(tmp) / response.json()["job_id"] / "manifest.json").read_text())
            self.assertEqual(manifest["application_context"]["borrower_inn"], "9900000017")
            queue.return_value.enqueue.assert_called_once()


if __name__ == "__main__":
    unittest.main()
