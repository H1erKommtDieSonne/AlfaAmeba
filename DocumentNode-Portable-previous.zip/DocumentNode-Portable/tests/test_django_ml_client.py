import unittest
from unittest.mock import patch

import httpx

from integration.django_ml_client import MLNodeClient, MLNodeError


class DjangoMLClientTests(unittest.TestCase):
    def financial(self):
        return {"application": {"application_id": "125", "document_version": 2}, "readiness": {"annual_model": True},
                "annual_model_input": {"unit": "RUB_THOUSANDS", "period_end": "2025-12-31", "metrics": {"revenue": 85.}},
                "is_mock": False, "model_outputs": {"status": "not_run"}, "warnings": []}

    def test_not_ready_and_mock_guard(self):
        client = MLNodeClient("http://ml", "test")
        financial = self.financial()
        financial["readiness"]["annual_model"] = False
        with self.assertRaises(MLNodeError): client.predict_financial_analysis(financial)
        financial = self.financial()
        financial["is_mock"] = True
        with self.assertRaises(MLNodeError): client.predict_financial_analysis(financial)

    def test_bank_view_preserves_original_and_checks_version(self):
        response = {"schema_version": 1, "application_id": "125", "document_version": 2, "is_mock": False,
                    "model_outputs": {"status": "completed"}, "warnings": [{"code": "defaults", "severity": "medium", "message": "test"}]}
        requests = []
        def handler(request):
            requests.append(request)
            return httpx.Response(200, json=response)
        real_client = httpx.Client
        def client(**kwargs):
            return real_client(transport=httpx.MockTransport(handler), **kwargs)
        with patch("integration.django_ml_client.httpx.Client", client):
            original = self.financial()
            bank_view, audit = MLNodeClient("http://ml", "test").build_bank_view(original)
            self.assertEqual(original["model_outputs"]["status"], "not_run")
            self.assertEqual(bank_view["model_outputs"]["status"], "completed")
            self.assertEqual(requests[0].url.params["reporting_year"], "2025")
            self.assertEqual(requests[0].headers["X-API-Key"], "test")
            response["document_version"] = 1
            with self.assertRaises(MLNodeError): MLNodeClient("http://ml", "test").build_bank_view(original)
