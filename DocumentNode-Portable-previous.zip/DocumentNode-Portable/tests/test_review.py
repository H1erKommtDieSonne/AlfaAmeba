import json
import os
import sys
import tempfile
import types
import importlib
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "api"))
import callback
from review import validate_review


class ReviewTests(unittest.TestCase):
    def review(self):
        return {"status": "complete", "summary": "Проверено", "issues": [],
                "missing_documents": [], "recommendations": []}

    def test_truncation_prevents_complete(self):
        result = validate_review(self.review(), [{"filename": "a.pdf",
            "truncated": True, "uncertain_fragments": []}])
        self.assertEqual(result["status"], "needs_review")
        self.assertEqual(result["issues"][0]["filename"], "a.pdf")

    def test_fabricated_filename_rejected(self):
        value = self.review()
        value.update(status="needs_review", issues=[{"code": "missing_field",
            "message": "Не распознано", "suggestion": "Проверьте",
            "filename": "invented.pdf"}])
        with self.assertRaises(ValueError):
            validate_review(value, [])

    def test_feedback_retries_same_body_and_stops_on_conflict(self):
        job_id = "a" * 32
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / job_id
            folder.mkdir()
            body = json.dumps({"feedback_id": "stable", "job_id": job_id,
                               "issues": []}).encode()
            (folder / "feedback.json").write_bytes(body)
            requests = []
            statuses = iter([404, 200, 409])

            def handler(request):
                requests.append(request)
                return httpx.Response(next(statuses))

            real_client = httpx.Client
            def client(**kwargs):
                return real_client(transport=httpx.MockTransport(handler), **kwargs)

            with patch.object(callback, "JOBS_DIR", Path(tmp)), patch.dict(os.environ, {
                "CALLBACK_URL": "http://django/api/v1/document-node/callback/",
                "CALLBACK_TOKEN": "test-token",
            }), patch.object(callback.httpx, "Client", client):
                with self.assertRaises(httpx.HTTPStatusError):
                    callback.deliver_feedback(job_id)
                self.assertFalse((folder / "feedback-receipt.json").exists())
                self.assertTrue(callback.deliver_feedback(job_id)["delivered"])
                self.assertTrue(callback.deliver_feedback(job_id)["requires_attention"])
            self.assertEqual([request.content for request in requests], [body] * 3)
            self.assertEqual(str(requests[0].url),
                             "http://django/api/v1/document-node/feedback/")
            self.assertEqual(requests[0].headers["Authorization"], "Bearer test-token")

    def test_processing_error_is_deliverable_and_reused(self):
        # Unit-test orchestration without invoking GPU/OCR or Redis.
        vision = types.ModuleType("vision")
        vision.vision_transcribe = None
        with patch.dict(sys.modules, {"vision": vision}):
            tasks = importlib.import_module("tasks")
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / ("b" * 32)
            folder.mkdir()
            context = {"application_id": "125", "document_version": 2}
            (folder / "manifest.json").write_text(json.dumps({
                "application_context": context,
                "files": [{"filename": "a.pdf"}],
            }))
            with patch.object(tasks, "JOBS_DIR", Path(tmp)), patch.dict(
                os.environ, {"CALLBACK_URL": ""}
            ), patch.object(tasks, "_analyze_documents", side_effect=RuntimeError("offline")) as analyze:
                with self.assertLogs(level="ERROR"):
                    tasks.process_documents(folder.name)
                first = (folder / "result.json").read_bytes()
                tasks.process_documents(folder.name)
                self.assertEqual(first, (folder / "result.json").read_bytes())
                self.assertEqual(analyze.call_count, 1)
            result = json.loads(first)
            self.assertEqual(result["status"], "completed")
            self.assertEqual(result["result"]["status"], "processing_error")
            self.assertEqual(result["result"]["issues"], [])
            self.assertEqual(result["result"]["application_context"], context)
            self.assertFalse((folder / "feedback.json").exists())


if __name__ == "__main__":
    unittest.main()
