"""Focused tests for the credit-product context in the final analysis request.

No network call and no model generation: the real ``httpx`` boundary is mocked.
The test proves that the one service and the one configured model are reused and
that the request carries the product, purpose, units and ML status needed for an
explicit product-aware assessment.
"""

import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "api"))

import final_analysis
from finance_prompt import FINANCIAL_SYSTEM_PROMPT
from finance_schema import ApplicationContext
from test_final_analysis import model_output, sample_analysis

MODEL = "qwen3.5:35b-a3b"
OLLAMA_URL = "http://ollama:11434"


class _Response:
    def __init__(self, content):
        self._content = content

    def raise_for_status(self):
        return None

    def json(self):
        return {"done_reason": "stop", "message": {"content": self._content}}


def _context():
    return ApplicationContext.model_validate({
        "application_id": "125",
        "document_version": 1,
        "borrower_inn": "9900000017",
        "product_code": "working-capital",
        "loan_type": "working_capital",
        "loan_amount_rub": 1500000.0,
        "term_months": 12,
        "purpose": "Пополнение оборотных средств для закупки сезонной партии",
        "annual_rate_percent": 18.5,
        "has_collateral": False,
        "proposed_monthly_payment_rub": 145000.0,
        "analysis_date": "2026-10-26",
    })


class CreditContextRequestTests(unittest.TestCase):
    def test_same_service_and_model_with_product_evidence_and_explicit_ctx(self):
        with patch("httpx.Client.post", return_value=_Response(model_output())) as post:
            result = final_analysis.build_final_analysis(
                sample_analysis(), _context(),
                ollama_url=OLLAMA_URL, model=MODEL, enabled=True, timeout=10,
                num_predict=1500,
            )

        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["provenance"]["model"], MODEL)
        args, kwargs = post.call_args
        self.assertEqual(args[-1], OLLAMA_URL + "/api/chat")
        payload = kwargs["json"]
        self.assertEqual(payload["model"], MODEL)
        self.assertEqual(payload["options"]["num_ctx"], 32768)
        self.assertEqual(payload["options"]["num_predict"], 1500)
        self.assertGreaterEqual(payload["options"]["num_predict"], 1400)

        system = payload["messages"][0]["content"]
        self.assertEqual(system, final_analysis.SYSTEM_PROMPT)
        self.assertNotEqual(system, FINANCIAL_SYSTEM_PROMPT)
        for term in (
            "product_code", "loan_type", "purpose", "model_outputs",
            "safe_credit_limit_rub_thousands", "unit", "failed", "not_run",
            "не решение банка",
        ):
            self.assertIn(term, system)

        user = payload["messages"][1]["content"]
        evidence = json.loads(user.split("\n", 1)[1])
        application = evidence["application"]
        self.assertEqual(application["product_code"], "working-capital")
        self.assertEqual(application["loan_type"], "working_capital")
        self.assertIn("оборотных средств", application["purpose"])
        self.assertEqual(application["loan_amount_rub"], 1500000.0)
        self.assertEqual(application["term_months"], 12)
        self.assertEqual(application["proposed_monthly_payment_rub"], 145000.0)
        self.assertIs(application["has_collateral"], False)
        self.assertEqual(evidence["units"]["annual_model_input_metrics"], "RUB_THOUSANDS")
        self.assertEqual(evidence["model_outputs"]["status"], "completed")
        self.assertEqual(evidence["model_outputs"]["safe_credit_limit_rub_thousands"], 17000.0)
        self.assertEqual(evidence["statistics"]["dscr"]["unit"], "ratio")
        self.assertEqual(evidence["statistics"]["dscr"]["status"], "available")
        self.assertNotIn("approval_probability_percent", evidence["model_outputs"])
        self.assertNotIn("decision", evidence["model_outputs"])
        for secret in ("secret-statement.pdf", "SECRET QUOTE", "9900000017"):
            self.assertNotIn(secret, user)

    def test_failed_or_not_run_ml_is_explicit_and_not_invented(self):
        for status in ("failed", "not_run"):
            with self.subTest(status=status):
                analysis = sample_analysis()
                analysis["model_outputs"] = {"status": status, "note": "raw"}
                evidence = final_analysis.build_evidence(analysis, _context())
                self.assertEqual(evidence["model_outputs"]["status"], status)
                self.assertNotIn("safe_credit_limit_rub_thousands",
                                 evidence["model_outputs"])
                self.assertNotIn("approval_probability_percent",
                                 evidence["model_outputs"])

    def test_ctx_is_configurable_only_between_allowed_windows(self):
        self.assertEqual(final_analysis._num_ctx(None), 32768)
        self.assertEqual(final_analysis._num_ctx(65536), 65536)
        self.assertEqual(final_analysis._num_ctx(16384), 32768)
        self.assertEqual(final_analysis._num_ctx(131072), 32768)


if __name__ == "__main__":
    unittest.main()
