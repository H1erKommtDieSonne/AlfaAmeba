import asyncio
import importlib.util
import io
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "api"))


@unittest.skipUnless(importlib.util.find_spec("pymupdf"), "PyMuPDF is verified in the Docker runtime")
class VisionTests(unittest.TestCase):
    def test_tiff_reads_all_frames(self):
        from PIL import Image
        import vision
        output = io.BytesIO()
        Image.new("RGB", (10, 10), "white").save(output, format="TIFF", save_all=True,
                                                   append_images=[Image.new("RGB", (10, 10), "black")])
        self.assertEqual(len(vision.prepare_images("pages.tiff", output.getvalue())), 2)

    def test_bad_model_json_is_technical_error(self):
        import vision
        from processing_errors import ModelProcessingError
        from PIL import Image
        real_client = httpx.AsyncClient
        def client(**kwargs):
            return real_client(transport=httpx.MockTransport(lambda request: httpx.Response(200, json=[])), **kwargs)
        with patch.object(vision, "prepare_images", return_value=[Image.new("RGB", (10, 10))]), patch.object(vision.httpx, "AsyncClient", client):
            with self.assertRaises(ModelProcessingError):
                asyncio.run(vision.vision_transcribe("a.png", b"unused", "http://unused"))

    def test_digital_pdf_uses_native_text(self):
        import pymupdf
        from analysis_pipeline import _text
        document = pymupdf.open()
        page = document.new_page()
        page.insert_text((50, 50), "Native financial statement text with enough characters for extraction 2025 RUB")
        content = document.tobytes()
        document.close()
        text, method, uncertain = _text("a.pdf", content, "http://unused")
        self.assertIn("financial", text)
        self.assertEqual(method, "pdf_text")
        self.assertEqual(uncertain, [])


if __name__ == "__main__":
    unittest.main()
