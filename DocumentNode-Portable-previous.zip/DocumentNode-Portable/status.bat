@echo off
pushd "%~dp0"
docker compose --profile mock --profile ml ps -a
docker compose exec -T worker rq info --url redis://redis:6379/0
popd
pause
